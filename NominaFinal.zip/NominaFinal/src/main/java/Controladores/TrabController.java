/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controladores;

import Domain.Trabajador;
import Servicios.TrabService;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author efren
 */
@RestController

@RequestMapping("/user")

public class TrabController {

    @Autowired
    TrabService service;

    @GetMapping("/list")
    public ResponseEntity<String> listaTrabajadores() {

        List<Trabajador> listaTrabajadores = service.getAllTrabajadores();

        String resultado = "";

        for (Trabajador u : listaTrabajadores) {
            resultado += u.getNombreTrab() + "/n";
        }

        return ResponseEntity.ok(resultado);
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getTrabajadorById(@PathVariable("id") String id) {

        Trabajador usuario = service.getTrabajadorById(id);

        if (usuario == null) {

            return ResponseEntity.noContent().build();
        } else {

            return ResponseEntity.ok(usuario.getNombreTrab());
        }
    }

    @GetMapping("/nombre/{name}")
    public List<Trabajador> getAllTrabajadoresByName(@PathVariable("name") String name) {

        List<Trabajador> listaTrabajadores = service.getTrabajadoresByName(name);

        return listaTrabajadores;
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    /*
    Buscar Nómina:
        Por empresa:
            -Todas de una empresa.
            -Todas de una empresa en un periodo concreto.
    
        Por trabajador:
            -Todas de un trabajador (todas las empresas).
            -De una empresa de un trabajador de un periodo.
            -De una empresa de un trabajador, todas.
    
    Generar Nómina:
        -Todas de una empresa en un año.                        V
        -De una empresa en un año en un periodo.
        -Todas las nóminas. (Todas empresas, todo de todo).
    */
    
    
    /*@GetMapping("/BuscarNomina/{Empresa}") //Busca todas las nóminas ya generadas de X empresa
    public String getNominasEmpresa(@PathVariable("Empresa")){
    
        
    
    }*/
    
    @PostMapping("GenerarNomina/{Empresa}/{anyo}") //Genera todas las nóminas de X Empresa en X año.
    public String makeNominasEmpresa(@PathVariable("Empresa") String CIFTrabaja, HttpServletRequest request, @PathVariable("anyo") String fecha){
        
        service.makeNominasEmpresa(CIFTrabaja, request, fecha);
        
        return "Controller";
    }
    
    /*@PostMapping("GenerarNomina/{Empresa}/{anyo}/{periodo}")
    public String makeNominasEmpresaMes(@PathVariable("Empresa") String CIFTrabaja, HttpServletRequest request, @PathVariable("anyo") String fecha, @PathVariable("periodo") String mes){
    
        service.makeNominaEmpresaMes(CIFTrabaja, request, fecha, mes);
        
        return "Controller";
    }*/
    
    @GetMapping("/salario/{NIF}/{anyo}")
    public String getSalarioBaseTrab(@PathVariable("NIF") String NIF, @PathVariable("anyo") String fecha, HttpServletRequest request){
        
        String salario = service.getSalarioBase(NIF, request, fecha);
    
        return salario;
    }
    
    /*@PostMapping("/domparser")
    public ResponseEntity<String> readXMLFile(HttpServletRequest request) {
        String response = service.getXMLContent(request);

        return ResponseEntity.ok(response);
    }*/
}
