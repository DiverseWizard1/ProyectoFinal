/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.severoochoa.springBootDemo.Repositorios;

import com.severoochoa.springBootDemo.Domain.Trabajador;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Efren
 */
@Repository
public interface TrabRepository extends JpaRepository<Trabajador, Long> {

    /**
     * Método que almacena objetos trabajador en la BD.
     * @param <S> -
     * @param s -
     * @return -
     */
    @Override
    <S extends Trabajador> S save(S s);

    /**
     * Método que busca todas los reqistros de objeto trabajador.
     * @return Lista de objetos trabajador.
     */
    @Override
    List<Trabajador> findAll();

    /**
     * Método que busca los registros de objeto trabajador con un ID concreto.
     * @param NIF ID del trabajador.
     * @return Dato de tipo Optional que contiene un lista de objetos trabajador.
     */
    Optional<Trabajador> findByNIF(String NIF);
    
    /**
     * Método que busca los registros de objeto trabajador con un nombre concreto.
     * @param nombreTrab Nombre del trabajador.
     * @return Dato de tipo Optional que contiene una lista de objetos trabajador.
     */
    Optional<List <Trabajador>> findAllTrabajadoresByNombreTrab(String nombreTrab);
}
