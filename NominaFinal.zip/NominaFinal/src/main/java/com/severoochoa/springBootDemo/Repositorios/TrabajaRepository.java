/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.severoochoa.springBootDemo.Repositorios;

import com.severoochoa.springBootDemo.Domain.Trabaja;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Joel Andreu 1CFS J
 */
@Repository
public interface TrabajaRepository extends JpaRepository<Trabaja, Long>{
    
    Optional<List<Trabaja>> findAllTrabajaByciftrabaja(String ciftrabaja);
    
}
