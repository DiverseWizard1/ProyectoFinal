/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.severoochoa.springBootDemo.Repositorios;

import com.severoochoa.springBootDemo.Domain.Trabaja;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Joel Andreu 1CFS J
 */
@Repository
public interface TrabajaRepository extends JpaRepository<Trabaja, Long>{
    
    /**
     * Método que busca todas los reqistros de objeto trabaja en la BD.
     * @return Lista de objetos trabaja
     */
    @Override
    List<Trabaja> findAll();
    
    /**
     * Método que busca los registros de objeto trabaja con un ID concreto de empresa.
     * @param ciftrabaja ID de empresa.
     * @return Dato de tipo Optional que contiene una lista de objetos trabaja.
     */
    Optional<List<Trabaja>> findAllTrabajaByciftrabaja(String ciftrabaja);
    
}
