/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.severoochoa.springBootDemo.Classes;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import com.severoochoa.springBootDemo.Domain.Empresa;
import com.severoochoa.springBootDemo.Domain.Nomina;
import com.severoochoa.springBootDemo.Domain.Trabajador;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;

/**
 *
 * @author Joel Andreu 1CFS J
 */
public class PDFGenerator {

    /**
     * Método que devuelve un double formateado con 2 decimales.
     * @param numero Número a formatear.
     * @return Double formateado.
     */
    public static double formateador(double numero) {

        try {
            
            DecimalFormat formateador = new DecimalFormat("####.##");
            numero = formateador.parse(formateador.format(numero)).doubleValue();
        } catch (Exception ex) {
            
            System.out.println("Error: " + ex.getMessage());
        }
        return numero;
    }

    /**
     * Método que crea y guarda archivos PDF
     * @param n Objeto tipo nómina.
     * @param e Objeto tipo empresa.
     * @param t Objeto tipo trabajador.
     * @param ruta String con el nombre del archivo PDF.
     * @param salarioBase Salario base del trabajador t pasado.
     * @param hExtra Horas extra del trabajador t pasado.
     * @throws IOException
     * @throws DocumentException
     * @throws ParseException 
     */
    public static void crearPDF(Nomina n, Empresa e, Trabajador t, String ruta, String salarioBase, String hExtra) throws IOException, DocumentException, ParseException {

        double BCCC = n.getCcc() / 0.047;
        double BCCP = BCCC + Double.parseDouble(hExtra);
        
        double salarioMes = (Double.parseDouble(salarioBase)) / 15;
        salarioMes = formateador(salarioMes);

        double totaport = n.getCcc() + n.getDesempleo() + (BCCP * 0.001) + (Double.parseDouble(hExtra) * 0.047);
        totaport = formateador(totaport);

        double irpf = BCCP * 0.12;
        irpf = formateador(irpf);

        double fprof = BCCP * 0.001;
        fprof = formateador(fprof);

        double totdeducir = totaport + (BCCP * 0.12);
        totdeducir = formateador(totdeducir);

        double liquidoTot = ((n.getTotDeveng()) - totdeducir);
        liquidoTot = formateador(liquidoTot);

        double horasExtra = Double.parseDouble(hExtra) * 0.047;
        horasExtra = formateador(horasExtra);

        //Creamos el documento y seleccionamos la ruta donde se va a crear.
        Document document = new Document();
        PdfWriter.getInstance(document, new FileOutputStream(".\\src\\test\\resources\\PDFsRetos\\" + ruta));

        //Abrimos el documento.
        document.open();

        //Le damos "formato", lo voy a hacer mediante dos columnas y tablas.
        float[] pointColumnWidths = {150F, 150F};
        PdfPTable table = new PdfPTable(pointColumnWidths);

        //Ponemos los Strings.
        String encabezadoEmpresa = "EMPRESA";
        String encabezadoTrabajador = "TRABAJADOR";
        String domEmpresa = "Domicilio: " + e.getDomicilio();
        String nifTrabajador = "NIF: " + t.getNIF();
        String cifEmpresa = "CIF: " + e.getCIF();
        String SS = "Núm. Afil. SS: " + t.getNumSS();
        String CCC = "CCC: " + e.getCCC();
        String gProf = "Grupo profesional: " + t.getGrupoProf();
        String s9 = "";
        String gCotiza = "Grupo de cotización: " + t.getNivelProf();

        //Metemos los Strings en frases.
        Phrase p1 = new Phrase(encabezadoEmpresa);
        Phrase p2 = new Phrase(encabezadoTrabajador);
        Phrase p3 = new Phrase(domEmpresa);
        Phrase p4 = new Phrase(nifTrabajador);
        Phrase p5 = new Phrase(cifEmpresa);
        Phrase p6 = new Phrase(SS);
        Phrase p7 = new Phrase(CCC);
        Phrase p8 = new Phrase(gProf);
        Phrase p9 = new Phrase(s9);
        Phrase p10 = new Phrase(gCotiza);

        //Creamos las celdas.
        PdfPCell c1 = new PdfPCell();
        PdfPCell c2 = new PdfPCell();
        PdfPCell c3 = new PdfPCell();
        PdfPCell c4 = new PdfPCell();
        PdfPCell c5 = new PdfPCell();
        PdfPCell c6 = new PdfPCell();
        PdfPCell c7 = new PdfPCell();
        PdfPCell c8 = new PdfPCell();
        PdfPCell c9 = new PdfPCell();
        PdfPCell c10 = new PdfPCell();

        Paragraph para1 = new Paragraph(p1);
        para1.setAlignment(p1.ALIGN_CENTER);

        Paragraph para2 = new Paragraph(p2);
        para2.setAlignment(p2.ALIGN_CENTER);

        //Añadimos las frases a las celdas y les damos formato.
        c1.addElement(para1);
        c1.setBorderWidthTop(1);
        c1.setBorderWidthLeft(1);
        c1.setBackgroundColor(BaseColor.LIGHT_GRAY);

        c2.addElement(para2);
        c2.setBorderWidthRight(1);
        c2.setBorderWidthTop(1);
        c2.setBackgroundColor(BaseColor.LIGHT_GRAY);

        c3.addElement(p3);
        c3.setBorder(0);
        c3.setBorderWidthLeft(1);
        c3.setBorderWidthRight(1);

        c4.addElement(p4);
        c4.setBorder(0);
        c4.setBorderWidthRight(1);
        c4.setBorderWidthLeft(1);

        c5.addElement(p5);
        c5.setBorder(0);
        c5.setBorderWidthLeft(1);
        c5.setBorderWidthRight(1);

        c6.addElement(p6);
        c6.setBorder(0);
        c6.setBorderWidthRight(1);
        c6.setBorderWidthLeft(1);

        c7.addElement(p7);
        c7.setBorder(0);
        c7.setBorderWidthLeft(1);
        c7.setBorderWidthRight(1);

        c8.addElement(p8);
        c8.setBorder(0);
        c8.setBorderWidthRight(1);
        c8.setBorderWidthLeft(1);

        c9.addElement(p9);
        c9.setBorder(0);
        c9.setBorderWidthBottom(1);
        c9.setBorderWidthLeft(1);
        c9.setBorderWidthRight(1);

        c10.addElement(p10);
        c10.setBorder(0);
        c10.setBorderWidthBottom(1);
        c10.setBorderWidthRight(1);
        c10.setBorderWidthLeft(1);

        //Metemos las celdas en la tabla.
        table.addCell(c1);
        table.addCell(c2);
        table.addCell(c3);
        table.addCell(c4);
        table.addCell(c5);
        table.addCell(c6);
        table.addCell(c7);
        table.addCell(c8);
        table.addCell(c9);
        table.addCell(c10);

        //Añadimos la tabla al documento y lo cerramos.
        document.add(table);

        float[] pointColumnWidths2 = {150F, 150F, 100F};
        PdfPTable table2 = new PdfPTable(pointColumnWidths2);

        String s11 = "";
        String s12 = "_";
        String s13 = "";
        String s14 = "I.DEVENGOS";
        String s15 = "";
        String s16 = "TOTALES";
        String s17 = "1- P. SALARIALES";
        String s18 = " 2- P. NO SALARIALES";
        String s19 = "";
        String s20 = "Salario base: " + salarioMes + " €";
        String s21 = "Prestaciones: " + n.getPrestaciones() + " €";
        String s22 = "";
        String s23 = "Horas Extra: " + hExtra + " €";
        String s24 = "Indemni.Traslado: " + n.getIndemniTraslado() + " €";
        String s25 = "";
        String s26 = "Grat.Ext: " + n.getGratifExtra() + " €";
        String s27 = "";
        String s28 = "";
        String s29 = " ";
        String s30 = " ";
        String s31 = " ";
        String s32 = "II.DEDUCCIONES";
        String s33 = " A. TOTAL DEVENGADO";
        String s34 = " " + n.getTotDeveng() + " €";

        String es1 = " APORTACIONES: ";
        String es2 = " ";
        String es3 = " ";

        String s35 = " ";
        String s36 = " 1.TOTAL APORTACIONES";
        String s37 = "     " + totaport + " €";

        String es4 = " ";
        String es5 = " ";
        String es6 = " ";

        String s38 = " Contingencias comunes    4.7%    " + n.getCcc() + " €";
        String s39 = " 2.I.R.P.F           12.00%";
        String s40 = "     " + irpf + " €";

        String es7 = " ";
        String es8 = " ";
        String es9 = " ";

        String s41 = " Desempleo                       " + (Double.parseDouble(n.getPorcentajedesem()) * 100) + "%    " + n.getDesempleo() + " €";
        String s42 = " ";
        String s43 = " ";

        String es10 = " ";
        String es11 = " ";
        String es12 = " ";

        String s44 = " Formación profesional     0.1%   " + fprof + " ";
        String s45 = " ";
        String s46 = " ";

        String es13 = " ";
        String es14 = " ";
        String es15 = " ";

        String s47 = " Horas extraordinarias        4.7%  " + horasExtra + " €";
        String s48 = " ";
        String s49 = " ";

        String es16 = " ";
        String es17 = " ";
        String es18 = " ";

        String s50 = "";
        String s51 = " B. TOTAL A DEDUCIR (1+2)";
        String s52 = "   " + totdeducir + " €";
        String s53 = " ";
        String s54 = " LIQUIDO TOTAL A PERCIBIR (A - B)";
        String s55 = "  " + liquidoTot + " €";

        Phrase p11 = new Phrase(s11);
        Phrase p12 = new Phrase(s12);
        Phrase p13 = new Phrase(s13);
        Phrase p14 = new Phrase(s14);
        Phrase p15 = new Phrase(s15);
        Phrase p16 = new Phrase(s16);
        Phrase p17 = new Phrase(s17);
        Phrase p18 = new Phrase(s18);
        Phrase p19 = new Phrase(s19);
        Phrase p20 = new Phrase(s20);
        Phrase p21 = new Phrase(s21);
        Phrase p22 = new Phrase(s22);
        Phrase p23 = new Phrase(s23);
        Phrase p24 = new Phrase(s24);
        Phrase p25 = new Phrase(s25);
        Phrase p26 = new Phrase(s26);
        Phrase p27 = new Phrase(s27);
        Phrase p28 = new Phrase(s28);
        Phrase p29 = new Phrase(s29);
        Phrase p30 = new Phrase(s30);
        Phrase p31 = new Phrase(s31);
        Phrase p32 = new Phrase(s32);
        Phrase p33 = new Phrase(s33);
        Phrase p34 = new Phrase(s34);
        Phrase p35 = new Phrase(s35);
        Phrase p36 = new Phrase(s36);
        Phrase p37 = new Phrase(s37);
        Phrase p38 = new Phrase(s38);
        Phrase p39 = new Phrase(s39);
        Phrase p40 = new Phrase(s40);
        Phrase p41 = new Phrase(s41);
        Phrase p42 = new Phrase(s42);
        Phrase p43 = new Phrase(s43);
        Phrase p44 = new Phrase(s44);
        Phrase p45 = new Phrase(s45);
        Phrase p46 = new Phrase(s46);
        Phrase p47 = new Phrase(s47);
        Phrase p48 = new Phrase(s48);
        Phrase p49 = new Phrase(s49);
        Phrase p50 = new Phrase(s50);
        Phrase p51 = new Phrase(s51);
        Phrase p52 = new Phrase(s52);
        Phrase p53 = new Phrase(s53);
        Phrase p54 = new Phrase(s54);
        Phrase p55 = new Phrase(s55);

        Phrase ep1 = new Phrase(es1);
        Phrase ep2 = new Phrase(es2);
        Phrase ep3 = new Phrase(es3);
        Phrase ep4 = new Phrase(es4);
        Phrase ep5 = new Phrase(es5);
        Phrase ep6 = new Phrase(es6);
        Phrase ep7 = new Phrase(es7);
        Phrase ep8 = new Phrase(es8);
        Phrase ep9 = new Phrase(es9);
        Phrase ep10 = new Phrase(es10);
        Phrase ep11 = new Phrase(es11);
        Phrase ep12 = new Phrase(es12);
        Phrase ep13 = new Phrase(es13);
        Phrase ep14 = new Phrase(es14);
        Phrase ep15 = new Phrase(es15);
        Phrase ep16 = new Phrase(es16);
        Phrase ep17 = new Phrase(es17);
        Phrase ep18 = new Phrase(es18);

        PdfPCell c11 = new PdfPCell();
        PdfPCell c12 = new PdfPCell();
        PdfPCell c13 = new PdfPCell();
        PdfPCell c14 = new PdfPCell();
        PdfPCell c15 = new PdfPCell();
        PdfPCell c16 = new PdfPCell();
        PdfPCell c17 = new PdfPCell();
        PdfPCell c18 = new PdfPCell();
        PdfPCell c19 = new PdfPCell();
        PdfPCell c20 = new PdfPCell();
        PdfPCell c21 = new PdfPCell();
        PdfPCell c22 = new PdfPCell();
        PdfPCell c23 = new PdfPCell();
        PdfPCell c24 = new PdfPCell();
        PdfPCell c25 = new PdfPCell();
        PdfPCell c26 = new PdfPCell();
        PdfPCell c27 = new PdfPCell();
        PdfPCell c28 = new PdfPCell();
        PdfPCell c29 = new PdfPCell();
        PdfPCell c30 = new PdfPCell();
        PdfPCell c31 = new PdfPCell();
        PdfPCell c32 = new PdfPCell();
        PdfPCell c33 = new PdfPCell();
        PdfPCell c34 = new PdfPCell();
        PdfPCell c35 = new PdfPCell();
        PdfPCell c36 = new PdfPCell();
        PdfPCell c37 = new PdfPCell();
        PdfPCell c38 = new PdfPCell();
        PdfPCell c39 = new PdfPCell();
        PdfPCell c40 = new PdfPCell();
        PdfPCell c41 = new PdfPCell();
        PdfPCell c42 = new PdfPCell();
        PdfPCell c43 = new PdfPCell();
        PdfPCell c44 = new PdfPCell();
        PdfPCell c45 = new PdfPCell();
        PdfPCell c46 = new PdfPCell();
        PdfPCell c47 = new PdfPCell();
        PdfPCell c48 = new PdfPCell();
        PdfPCell c49 = new PdfPCell();
        PdfPCell c50 = new PdfPCell();
        PdfPCell c51 = new PdfPCell();
        PdfPCell c52 = new PdfPCell();
        PdfPCell c53 = new PdfPCell();
        PdfPCell c54 = new PdfPCell();
        PdfPCell c55 = new PdfPCell();

        PdfPCell ce1 = new PdfPCell();
        PdfPCell ce2 = new PdfPCell();
        PdfPCell ce3 = new PdfPCell();
        PdfPCell ce4 = new PdfPCell();
        PdfPCell ce5 = new PdfPCell();
        PdfPCell ce6 = new PdfPCell();
        PdfPCell ce7 = new PdfPCell();
        PdfPCell ce8 = new PdfPCell();
        PdfPCell ce9 = new PdfPCell();
        PdfPCell ce10 = new PdfPCell();
        PdfPCell ce11 = new PdfPCell();
        PdfPCell ce12 = new PdfPCell();
        PdfPCell ce13 = new PdfPCell();
        PdfPCell ce14 = new PdfPCell();
        PdfPCell ce15 = new PdfPCell();
        PdfPCell ce16 = new PdfPCell();
        PdfPCell ce17 = new PdfPCell();
        PdfPCell ce18 = new PdfPCell();

        //Creamos paragrafos, metemos las frases que queramos y centramos el texto.
        Paragraph para14 = new Paragraph(p14);
        para14.setAlignment(p14.ALIGN_CENTER);

        Paragraph para16 = new Paragraph(p16);
        para16.setAlignment(p16.ALIGN_CENTER);

        Paragraph para32 = new Paragraph(p32);
        para32.setAlignment(p32.ALIGN_CENTER);

        c11.addElement(p11);
        c11.setBorder(0);
        c11.setBorderWidthTop(1);
        c11.setBorderWidthBottom(1);

        c12.addElement(p12);
        c12.setBorder(0);
        c12.setBorderWidthTop(1);
        c12.setBorderWidthBottom(1);

        c13.addElement(p13);
        c13.setBorder(0);
        c13.setBorderWidthTop(1);
        c13.setBorderWidthBottom(1);

        c14.addElement(para14);
        c14.setBorderWidthTop(1);
        c14.setBorderWidthLeft(1);
        c14.setBackgroundColor(BaseColor.LIGHT_GRAY);

        c15.addElement(p15);
        c15.setBorder(0);
        c15.setBorderWidthTop(1);

        c16.addElement(para16);
        c16.setBorderWidthRight(1);
        c16.setBorderWidthTop(1);
        c16.setBackgroundColor(BaseColor.LIGHT_GRAY);

        c17.addElement(p17);
        c17.setBorder(0);
        c17.setBorderWidthLeft(1);

        c18.addElement(p18);
        c18.setBorder(0);

        c19.addElement(p19);
        c19.setBorder(0);
        c19.setBorderWidthRight(1);

        c20.addElement(p20);
        c20.setBorder(0);
        c20.setBorderWidthLeft(1);

        c21.addElement(p21);
        c21.setBorder(0);

        c22.addElement(p22);
        c22.setBorder(0);
        c22.setBorderWidthRight(1);

        c23.addElement(p23);
        c23.setBorder(0);
        c23.setBorderWidthLeft(1);

        c24.addElement(p24);
        c24.setBorder(0);

        c25.addElement(p25);
        c25.setBorder(0);
        c25.setBorderWidthRight(1);

        c26.addElement(p26);
        c26.setBorder(0);
        c26.setBorderWidthLeft(1);

        c27.addElement(p27);
        c27.setBorder(0);

        c28.addElement(p28);
        c28.setBorder(0);
        c28.setBorderWidthRight(1);

        c29.addElement(p29);
        c29.setBorder(0);
        c29.setBorderWidthLeft(1);

        c30.addElement(p30);
        c30.setBorder(0);

        c31.addElement(p31);
        c31.setBorder(0);
        c31.setBorderWidthRight(1);

        c32.addElement(para32);
        c32.setBorderWidthTop(1);
        c32.setBorderWidthLeft(1);
        c32.setBackgroundColor(BaseColor.LIGHT_GRAY);

        c33.addElement(p33);
        c33.setBorder(0);

        c34.addElement(p34);

        c35.addElement(p35);
        c35.setBorder(0);
        c35.setBorderWidthLeft(1);

        c36.addElement(p36);
        c36.setBorder(0);

        c37.addElement(p37);
        c37.setBorder(0);
        c37.setBorderWidthRight(1);

        c38.addElement(p38);
        c38.setBorder(0);
        c38.setBorderWidthLeft(1);

        c39.addElement(p39);
        c39.setBorder(0);

        c40.addElement(p40);
        c40.setBorder(0);
        c40.setBorderWidthRight(1);

        c41.addElement(p41);
        c41.setBorder(0);
        c41.setBorderWidthLeft(1);

        c42.addElement(p42);
        c42.setBorder(0);

        c43.addElement(p43);
        c43.setBorder(0);
        c43.setBorderWidthRight(1);

        c44.addElement(p44);
        c44.setBorder(0);
        c44.setBorderWidthLeft(1);

        c45.addElement(p45);
        c45.setBorder(0);

        c46.addElement(p46);
        c46.setBorder(0);
        c46.setBorderWidthRight(1);

        c47.addElement(p47);
        c47.setBorder(0);
        c47.setBorderWidthLeft(1);

        c48.addElement(p48);
        c48.setBorder(0);

        c49.addElement(p49);
        c49.setBorder(0);
        c49.setBorderWidthRight(1);

        ce1.addElement(ep1);
        ce1.setBorder(0);
        ce1.setBorderWidthLeft(1);

        ce2.addElement(ep2);
        ce2.setBorder(0);

        ce3.addElement(ep3);
        ce3.setBorder(0);
        ce3.setBorderWidthRight(1);

        ce4.addElement(ep4);
        ce4.setBorder(0);
        ce4.setBorderWidthLeft(1);

        ce5.addElement(ep5);
        ce5.setBorder(0);

        ce6.addElement(ep6);
        ce6.setBorder(0);
        ce6.setBorderWidthRight(1);

        ce7.addElement(ep7);
        ce7.setBorder(0);
        ce7.setBorderWidthLeft(1);

        ce8.addElement(ep8);
        ce8.setBorder(0);

        ce9.addElement(ep9);
        ce9.setBorder(0);
        ce9.setBorderWidthRight(1);

        ce10.addElement(ep10);
        ce10.setBorder(0);
        ce10.setBorderWidthLeft(1);

        ce11.addElement(ep11);
        ce11.setBorder(0);

        ce12.addElement(ep12);
        ce12.setBorder(0);
        ce12.setBorderWidthRight(1);

        ce13.addElement(ep13);
        ce13.setBorder(0);
        ce13.setBorderWidthLeft(1);

        ce14.addElement(ep14);
        ce14.setBorder(0);

        ce15.addElement(ep15);
        ce15.setBorder(0);
        ce15.setBorderWidthRight(1);

        ce16.addElement(ep16);
        ce16.setBorder(0);
        ce16.setBorderWidthLeft(1);

        ce17.addElement(ep17);
        ce17.setBorder(0);

        ce18.addElement(ep18);
        ce18.setBorder(0);
        ce18.setBorderWidthRight(1);

        c50.addElement(p50);
        c50.setBorder(0);
        c50.setBorderWidthLeft(1);

        c51.addElement(p51);
        c51.setBorder(0);

        c52.addElement(p52);
        c52.setBorderWidthRight(1);

        c53.addElement(p53);
        c53.setBorder(0);
        c53.setBorderWidthLeft(1);
        c53.setBorderWidthBottom(1);

        c54.addElement(p54);
        c54.setBorder(0);
        c54.setBorderWidthBottom(1);

        c55.addElement(p55);
        c55.setBorderWidthRight(1);
        c55.setBorderWidthBottom(1);

        table2.addCell(c11);
        table2.addCell(c12);
        table2.addCell(c13);
        table2.addCell(c14);
        table2.addCell(c15);
        table2.addCell(c16);
        table2.addCell(c17);
        table2.addCell(c18);
        table2.addCell(c19);
        table2.addCell(c20);
        table2.addCell(c21);
        table2.addCell(c22);
        table2.addCell(c23);
        table2.addCell(c24);
        table2.addCell(c25);
        table2.addCell(c26);
        table2.addCell(c27);
        table2.addCell(c28);
        table2.addCell(c29);
        table2.addCell(c30);
        table2.addCell(c31);
        table2.addCell(c32);
        table2.addCell(c33);
        table2.addCell(c34);

        table2.addCell(ce1);
        table2.addCell(ce2);
        table2.addCell(ce3);

        table2.addCell(c35);
        table2.addCell(c36);
        table2.addCell(c37);

        table2.addCell(ce4);
        table2.addCell(ce5);
        table2.addCell(ce6);

        table2.addCell(c38);
        table2.addCell(c39);
        table2.addCell(c40);

        table2.addCell(ce7);
        table2.addCell(ce8);
        table2.addCell(ce9);

        table2.addCell(c41);
        table2.addCell(c42);
        table2.addCell(c43);

        table2.addCell(ce10);
        table2.addCell(ce11);
        table2.addCell(ce12);

        table2.addCell(c44);
        table2.addCell(c45);
        table2.addCell(c46);

        table2.addCell(ce13);
        table2.addCell(ce14);
        table2.addCell(ce15);

        table2.addCell(c47);
        table2.addCell(c48);
        table2.addCell(c49);

        table2.addCell(ce16);
        table2.addCell(ce17);
        table2.addCell(ce18);

        table2.addCell(c50);
        table2.addCell(c51);
        table2.addCell(c52);
        table2.addCell(c53);
        table2.addCell(c54);
        table2.addCell(c55);

        document.add(table2);

        float[] pointColumnWidths3 = {150F, 150F};
        PdfPTable table3 = new PdfPTable(pointColumnWidths3);

//Para que el pdf quede estético.
        String esp1 = "";
        String esp2 = " ";
        String esp3 = "";
        String esp4 = " ";
        String esp5 = "";
        String esp6 = " ";
        String esp7 = "";
        String esp8 = " ";
        String esp9 = "";
        String esp10 = " ";
        String esp11 = "";
        String esp12 = " ";
        String esp13 = "";
        String esp14 = " ";

//
//Primer bloque.
        String s56 = " ";
        String s57 = "";
        String s58 = " 1.Contingencias comunes";
        String s59 = " ";
        String s60 = " ";
        String s61 = " APORTACIÓN EMPRESA";
        String s62 = " Remuneración mensual:     " + salarioMes + " €";
        String s63 = "";
        String s64 = " Prorrata pagas extraord:    " + n.getGratifExtra() + " €";
        String s65 = "";
        String s66 = " Base Cotiza. S.SOC:          " + formateador(BCCC) + " €";
        String s67 = "       23.60%    " + formateador(BCCC * 0.236) + " €";
        String s68 = " ";
        String s69 = " ";
//
//Segundo bloque

        String s70 = " 2.Contingencias profesionales";
        String s71 = " ";
        String s72 = " ";
        String s73 = " ";
        String s74 = " Base Contingen. P:            " + formateador(BCCP) + " €";
        String s75 = " ";
        String s76 = " AT y EP";
        String s77 = "       1.5%      " + formateador(BCCP * 0.015) + " €";
        String s78 = " Desempleo";
        String s79 = "       " + (Double.parseDouble(n.getPorcentajedesememp()) * 100) + "%      " + formateador(n.getDesempleoemp()) + " €";
        String s80 = " Formación profesional";
        String s81 = "       0.6%      " + formateador(BCCP * 0.006) + " €";
        String s82 = " Fondo Garantía Salarial";
        String s83 = "       0.2%      " + formateador(BCCP * 0.002) + " €";
        String s84 = " ";
        String s85 = " ";
        String s86 = " 3.Cotización adicional horas extra";
        String s87 = "         %";
        String s88 = "      Total aportación empresarial";
        String s89 = "               " + formateador((BCCC * 0.236) + (BCCP * 0.015) + n.getDesempleoemp() + (BCCP * 0.006) + (BCCP * 0.002)) + " €";
        String s90 = " 4.Base de retención del I.R.P.F";
        String s91 = "               " + formateador(BCCP) + " €";

//Espacios en blanco
        Phrase pr1 = new Phrase(esp1);
        Phrase pr2 = new Phrase(esp2);
        Phrase pr3 = new Phrase(esp3);
        Phrase pr4 = new Phrase(esp4);
        Phrase pr5 = new Phrase(esp5);
        Phrase pr6 = new Phrase(esp6);
        Phrase pr7 = new Phrase(esp7);
        Phrase pr8 = new Phrase(esp8);
        Phrase pr9 = new Phrase(esp9);
        Phrase pr10 = new Phrase(esp10);
        Phrase pr11 = new Phrase(esp11);
        Phrase pr12 = new Phrase(esp12);
        Phrase pr13 = new Phrase(esp13);
        Phrase pr14 = new Phrase(esp14);

//
        Phrase p56 = new Phrase(s56);
        Phrase p57 = new Phrase(s57);
        Phrase p58 = new Phrase(s58);
        Phrase p59 = new Phrase(s59);
        Phrase p60 = new Phrase(s60);
        Phrase p61 = new Phrase(s61);
        Phrase p62 = new Phrase(s62);
        Phrase p63 = new Phrase(s63);
        Phrase p64 = new Phrase(s64);
        Phrase p65 = new Phrase(s65);
        Phrase p66 = new Phrase(s66);
        Phrase p67 = new Phrase(s67);
        Phrase p68 = new Phrase(s68);
        Phrase p69 = new Phrase(s69);
        Phrase p70 = new Phrase(s70);
        Phrase p71 = new Phrase(s71);
        Phrase p72 = new Phrase(s72);
        Phrase p73 = new Phrase(s73);
        Phrase p74 = new Phrase(s74);
        Phrase p75 = new Phrase(s75);
        Phrase p76 = new Phrase(s76);
        Phrase p77 = new Phrase(s77);
        Phrase p78 = new Phrase(s78);
        Phrase p79 = new Phrase(s79);
        Phrase p80 = new Phrase(s80);
        Phrase p81 = new Phrase(s81);
        Phrase p82 = new Phrase(s82);
        Phrase p83 = new Phrase(s83);
        Phrase p84 = new Phrase(s84);
        Phrase p85 = new Phrase(s85);
        Phrase p86 = new Phrase(s86);
        Phrase p87 = new Phrase(s87);
        Phrase p88 = new Phrase(s88);
        Phrase p89 = new Phrase(s89);
        Phrase p90 = new Phrase(s90);
        Phrase p91 = new Phrase(s91);

//Espacios en blanco.
        PdfPCell cr1 = new PdfPCell();
        PdfPCell cr2 = new PdfPCell();
        PdfPCell cr3 = new PdfPCell();
        PdfPCell cr4 = new PdfPCell();
        PdfPCell cr5 = new PdfPCell();
        PdfPCell cr6 = new PdfPCell();
        PdfPCell cr7 = new PdfPCell();
        PdfPCell cr8 = new PdfPCell();
        PdfPCell cr9 = new PdfPCell();
        PdfPCell cr10 = new PdfPCell();
        PdfPCell cr11 = new PdfPCell();
        PdfPCell cr12 = new PdfPCell();
        PdfPCell cr13 = new PdfPCell();
        PdfPCell cr14 = new PdfPCell();

//
        PdfPCell c56 = new PdfPCell();
        PdfPCell c57 = new PdfPCell();
        PdfPCell c58 = new PdfPCell();
        PdfPCell c59 = new PdfPCell();
        PdfPCell c60 = new PdfPCell();
        PdfPCell c61 = new PdfPCell();
        PdfPCell c62 = new PdfPCell();
        PdfPCell c63 = new PdfPCell();
        PdfPCell c64 = new PdfPCell();
        PdfPCell c65 = new PdfPCell();
        PdfPCell c66 = new PdfPCell();
        PdfPCell c67 = new PdfPCell();
        PdfPCell c68 = new PdfPCell();
        PdfPCell c69 = new PdfPCell();
        PdfPCell c70 = new PdfPCell();
        PdfPCell c71 = new PdfPCell();
        PdfPCell c72 = new PdfPCell();
        PdfPCell c73 = new PdfPCell();
        PdfPCell c74 = new PdfPCell();
        PdfPCell c75 = new PdfPCell();
        PdfPCell c76 = new PdfPCell();
        PdfPCell c77 = new PdfPCell();
        PdfPCell c78 = new PdfPCell();
        PdfPCell c79 = new PdfPCell();
        PdfPCell c80 = new PdfPCell();
        PdfPCell c81 = new PdfPCell();
        PdfPCell c82 = new PdfPCell();
        PdfPCell c83 = new PdfPCell();
        PdfPCell c84 = new PdfPCell();
        PdfPCell c85 = new PdfPCell();
        PdfPCell c86 = new PdfPCell();
        PdfPCell c87 = new PdfPCell();
        PdfPCell c88 = new PdfPCell();
        PdfPCell c89 = new PdfPCell();
        PdfPCell c90 = new PdfPCell();
        PdfPCell c91 = new PdfPCell();

        cr1.addElement(pr1);
        cr1.setBorder(0);

        cr2.addElement(pr2);
        cr2.setBorder(0);

        cr3.addElement(pr3);
        cr3.setBorder(0);

        cr4.addElement(pr4);
        cr4.setBorder(0);

        cr5.addElement(pr5);
        cr5.setBorder(0);

        cr6.addElement(pr6);
        cr6.setBorder(0);

        cr7.addElement(pr7);
        cr7.setBorder(0);

        cr8.addElement(pr8);
        cr8.setBorder(0);

        cr9.addElement(pr9);
        cr9.setBorder(0);

        cr10.addElement(pr10);
        cr10.setBorder(0);

        cr13.addElement(pr13);
        cr13.setBorder(0);

        cr14.addElement(pr14);
        cr14.setBorder(0);

        c56.addElement(p56);
        c56.setBorder(0);
        c56.setBorderWidthTop(1);
        c56.setBorderWidthLeft(1);

        c57.addElement(p57);
        c57.setBorder(0);
        c57.setBorderWidthTop(1);
        c57.setBorderWidthRight(1);

        c58.addElement(p58);
        c58.setBorder(0);
        c58.setBorderWidthLeft(1);

        c59.addElement(p59);
        c59.setBorder(0);
        c59.setBorderWidthRight(1);

        c60.addElement(p60);
        c60.setBorder(0);
        c60.setBorderWidthLeft(1);

        c61.addElement(p61);
        c61.setBorder(0);
        c61.setBorderWidthRight(1);

        c62.addElement(p62);
        c62.setBorder(0);
        c62.setBorderWidthLeft(1);

        c63.addElement(p63);
        c63.setBorder(0);
        c63.setBorderWidthRight(1);

        c64.addElement(p64);
        c64.setBorder(0);
        c64.setBorderWidthLeft(1);

        c65.addElement(p65);
        c65.setBorder(0);
        c65.setBorderWidthRight(1);

        c66.addElement(p66);
        c66.setBorder(0);
        c66.setBorderWidthLeft(1);

        c67.addElement(p67);
        c67.setBorder(0);
        c67.setBorderWidthRight(1);

        c68.addElement(p68);
        c68.setBorder(0);
        c68.setBorderWidthLeft(1);

        c69.addElement(p69);
        c69.setBorder(0);
        c69.setBorderWidthRight(1);

        c70.addElement(p70);
        c70.setBorder(0);
        c70.setBorderWidthLeft(1);

        c71.addElement(p71);
        c71.setBorder(0);
        c71.setBorderWidthRight(1);

        c72.addElement(p72);
        c72.setBorder(0);
        c72.setBorderWidthLeft(1);

        c73.addElement(p73);
        c73.setBorder(0);
        c73.setBorderWidthRight(1);

        c74.addElement(p74);
        c74.setBorder(0);
        c74.setBorderWidthLeft(1);

        c75.addElement(p75);
        c75.setBorder(0);
        c75.setBorderWidthRight(1);

        c76.addElement(p76);
        c76.setBorder(0);
        c76.setBorderWidthLeft(1);

        c77.addElement(p77);
        c77.setBorder(0);
        c77.setBorderWidthRight(1);

        c78.addElement(p78);
        c78.setBorder(0);
        c78.setBorderWidthLeft(1);

        c79.addElement(p79);
        c79.setBorder(0);
        c79.setBorderWidthRight(1);

        c80.addElement(p80);
        c80.setBorder(0);
        c80.setBorderWidthLeft(1);

        c81.addElement(p81);
        c81.setBorder(0);
        c81.setBorderWidthRight(1);

        c82.addElement(p82);
        c82.setBorder(0);
        c82.setBorderWidthLeft(1);

        c83.addElement(p83);
        c83.setBorder(0);
        c83.setBorderWidthRight(1);

        c84.addElement(p84);
        c84.setBorder(0);
        c84.setBorderWidthLeft(1);

        c85.addElement(p85);
        c85.setBorder(0);
        c85.setBorderWidthRight(1);

        c86.addElement(p86);
        c86.setBorder(0);
        c86.setBorderWidthLeft(1);

        c87.addElement(p87);
        c87.setBorder(0);
        c87.setBorderWidthRight(1);

        c88.addElement(p88);
        c88.setBorder(0);
        c88.setBorderWidthLeft(1);

        c89.addElement(p89);
        c89.setBorder(0);
        c89.setBorderWidthRight(1);

        c90.addElement(p90);
        c90.setBorder(0);
        c90.setBorderWidthLeft(1);

        c91.addElement(p91);
        c91.setBorder(0);
        c91.setBorderWidthRight(1);

        cr11.addElement(pr11);
        cr11.setBorder(0);
        cr11.setBorderWidthLeft(1);
        cr11.setBorderWidthBottom(1);

        cr12.addElement(pr12);
        cr12.setBorder(0);
        cr12.setBorderWidthRight(1);
        cr12.setBorderWidthBottom(1);

        table3.addCell(cr1);
        table3.addCell(cr2);
        table3.addCell(cr3);
        table3.addCell(cr4);
        table3.addCell(cr5);
        table3.addCell(cr6);
        table3.addCell(cr7);
        table3.addCell(cr8);
        table3.addCell(cr9);
        table3.addCell(cr10);

        table3.addCell(c56);
        table3.addCell(c57);
        table3.addCell(c58);
        table3.addCell(c59);
        table3.addCell(c60);
        table3.addCell(c61);
        table3.addCell(c62);
        table3.addCell(c63);
        table3.addCell(c64);
        table3.addCell(c65);
        table3.addCell(c66);
        table3.addCell(c67);
        table3.addCell(c68);
        table3.addCell(c69);
        table3.addCell(c70);
        table3.addCell(c71);
        table3.addCell(c72);
        table3.addCell(c73);
        table3.addCell(c74);
        table3.addCell(c75);
        table3.addCell(c76);
        table3.addCell(c77);
        table3.addCell(c78);
        table3.addCell(c79);
        table3.addCell(c80);
        table3.addCell(c81);
        table3.addCell(c82);
        table3.addCell(c83);
        table3.addCell(c84);
        table3.addCell(c85);
        table3.addCell(c86);
        table3.addCell(c87);
        table3.addCell(c88);
        table3.addCell(c89);
        table3.addCell(c90);
        table3.addCell(c91);
        table3.addCell(cr11);
        table3.addCell(cr12);

        document.add(table3);

        document.close();
    }
}
