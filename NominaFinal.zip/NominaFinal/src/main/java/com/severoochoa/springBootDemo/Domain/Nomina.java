/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.severoochoa.springBootDemo.Domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Joel Andreu 1CFS J
 */
@Entity
@Table(name = "nomina")
public class Nomina {
    
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY) // Esto significa autoincrementable
    @Column (name = "idnomina")
    private long IdNomina;
    @Column (name = "totdeduc")//
    private double TotDeduc;
    @Column (name = "totaportemp")//
    private double TotAportEmp;
    @Column (name = "fechainicio")
    private String FechaInicio;
    @Column (name = "fechafin")
    private String FechaFin;
    @Column (name = "gratifextra")//
    private double GratifExtra;
    @Column (name = "totaport")//
    private double TotAport;
    @Column (name = "totdeveng")//
    private double TotDeveng;
    @Column (name = "prestaciones")//
    private double Prestaciones;
    @Column (name = "indemnitraslado")//
    private double IndemniTraslado;
    @Column (name = "liquidotot")// 
    private double LiquidoTot;
    @Column (name = "nifnomina")//
    private String NIFNomina;
    @Column (name = "cifnomina")//
    private String CIFNomina;
    @Column (name = "capacitacionprofesional")//
    private double capacitacionProfesional;

    public Nomina(double TotDeduc, double TotAportEmp, String FechaInicio, String FechaFin, double GratifExtra, double TotAport, double TotDeveng, double Prestaciones, double IndemniTraslado, double LiquidoTot, String NIFNomina, String CIFNomina, double capacitacionProfesional) {
        this.TotDeduc = TotDeduc;
        this.TotAportEmp = TotAportEmp;
        this.FechaInicio = FechaInicio;
        this.FechaFin = FechaFin;
        this.GratifExtra = GratifExtra;
        this.TotAport = TotAport;
        this.TotDeveng = TotDeveng;
        this.Prestaciones = Prestaciones;
        this.IndemniTraslado = IndemniTraslado;
        this.LiquidoTot = LiquidoTot;
        this.NIFNomina = NIFNomina;
        this.CIFNomina = CIFNomina;
        this.capacitacionProfesional = capacitacionProfesional;
    }

    public Nomina(){
    
        this.TotDeduc = 0.0;
        this.TotAportEmp = 0.0;
        this.FechaInicio = "";
        this.FechaFin = "";
        this.GratifExtra = 0.0;
        this.TotAport = 0.0;
        this.TotDeveng = 0.0;
        this.Prestaciones = 0.0;
        this.IndemniTraslado = 0.0;
        this.LiquidoTot = 0.0;
        this.NIFNomina = "";
        this.CIFNomina = "";
        this.capacitacionProfesional = 0.0;
    
    }
    
    public long getIdNomina() {
        return IdNomina;
    }

    public void setIdNomina(long IdNomina) {
        this.IdNomina = IdNomina;
    }

    public double getTotDeduc() {
        return TotDeduc;
    }

    public void setTotDeduc(double TotDeduc) {
        this.TotDeduc = TotDeduc;
    }

    public double getTotAportEmp() {
        return TotAportEmp;
    }

    public void setTotAportEmp(double TotAportEmp) {
        this.TotAportEmp = TotAportEmp;
    }

    public String getFechaInicio() {
        return FechaInicio;
    }

    public void setFechaInicio(String FechaInicio) {
        this.FechaInicio = FechaInicio;
    }

    public String getFechaFin() {
        return FechaFin;
    }

    public void setFechaFin(String FechaFin) {
        this.FechaFin = FechaFin;
    }

    public double getGratifExtra() {
        return GratifExtra;
    }

    public void setGratifExtra(double GratifExtra) {
        this.GratifExtra = GratifExtra;
    }

    public double getTotAport() {
        return TotAport;
    }

    public void setTotAport(double TotAport) {
        this.TotAport = TotAport;
    }

    public double getTotDeveng() {
        return TotDeveng;
    }

    public void setTotDeveng(double TotDeveng) {
        this.TotDeveng = TotDeveng;
    }

    public double getPrestaciones() {
        return Prestaciones;
    }

    public void setPrestaciones(double Prestaciones) {
        this.Prestaciones = Prestaciones;
    }

    public double getIndemniTraslado() {
        return IndemniTraslado;
    }

    public void setIndemniTraslado(double IndemniTraslado) {
        this.IndemniTraslado = IndemniTraslado;
    }

    public double getLiquidoTot() {
        return LiquidoTot;
    }

    public void setLiquidoTot(double LiquidoTot) {
        this.LiquidoTot = LiquidoTot;
    }

    public String getNIFNomina() {
        return NIFNomina;
    }

    public void setNIFNomina(String NIFNomina) {
        this.NIFNomina = NIFNomina;
    }

    public String getCIFNomina() {
        return CIFNomina;
    }

    public void setCIFNomina(String CIFNomina) {
        this.CIFNomina = CIFNomina;
    }
    
    
    
}
