/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.severoochoa.springBootDemo.Domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author efren
 */
@Entity
@Table(name = "empresa")
public class Empresa {

    @Id
    @Column (name = "cif")
    private String CIF;
    @Column(name = "ccc")
    private Long CCC;
    @Column(name = "domicilio")
    private String Domicilio;
    @Column(name = "nombreemp")
    private String nombreEmp;

    public String getCIF() {
        return CIF;
    }

    public void setCIF(String CIF) {
        this.CIF = CIF;
    }

    public Long getCCC() {
        return CCC;
    }

    public void setCCC(Long CCC) {
        this.CCC = CCC;
    }

    public String getDomicilio() {
        return Domicilio;
    }

    public void setDomicilio(String grupoProf) {
        this.Domicilio = Domicilio;
    }

    public String getNombreEmp() {
        return nombreEmp;
    }

    public void setNombreEmp(String nombreEmp) {
        this.nombreEmp = nombreEmp;
    }

}
