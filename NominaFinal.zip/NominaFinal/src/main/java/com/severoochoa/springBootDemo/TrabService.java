/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.severoochoa.springBootDemo;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 *
 * @author Efren
 */
@Service
public class TrabService {

    @Autowired(required = false)
    TrabRepository repository;

    public void trabajadorInformation(String nombreTrab, String apellido) {

        Trabajador usuario = new Trabajador();
        usuario.setNombreTrab(nombreTrab);
        usuario.setApellido(apellido);

        repository.save(usuario);
    }

    public List getAllTrabajadores() {

        List<Trabajador> listaTrabajadores = repository.findAll();

        return listaTrabajadores;
    }

    public Trabajador getTrabajadorById(String id) {

        Optional<Trabajador> usuario = repository.findByNIF(id);

        if (usuario.isPresent()) {

            return usuario.get();
        } else {

            return null;
        }
    }

    public List<Trabajador> getTrabajadoresByName(String nombreTrab) {

        Optional<List<Trabajador>> listaTrabajadores = repository.findAllTrabajadoresByNombreTrab(nombreTrab);

        if (listaTrabajadores.isPresent()) {

            return listaTrabajadores.get();
        } else {

            return null;
        }
    }

    public String getFileContent(HttpServletRequest request) {

        String fileContent = "";

        try {
            InputStream input = request.getInputStream();

            byte[] data = new byte[1024];

            ByteArrayOutputStream buffer = new ByteArrayOutputStream();

            int nRead;
            while ((nRead = input.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, nRead);
            }

            buffer.flush();
            fileContent = new String(buffer.toByteArray());

        } catch (IOException ex) {
            System.err.println("Error! " + ex.getMessage());
        }

        return fileContent;
    }

    public String getXMLContent(HttpServletRequest request) {

        String tree = "";

        String fileContent = getFileContent(request);

        // Instantiate the Factory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {

            // optional, but recommended
            // process XML securely, avoid attacks like XML External Entities (XXE)
            //dbf.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            // parse XML file
            DocumentBuilder db = dbf.newDocumentBuilder();

            org.w3c.dom.Document doc = db.parse(new InputSource(new StringReader(fileContent)));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            tree += "Root Element :" + doc.getDocumentElement().getNodeName() + "\n";
            tree += "------\n";

            // get <anyo>
            NodeList anyoList = doc.getElementsByTagName("anyo");

            for (int i = 0; i < anyoList.getLength(); i++) {

                Node nodeAnyo = anyoList.item(i);

                Element elementAnyo = (Element) nodeAnyo;
                
                //get fecha
                String fecha = elementAnyo.getElementsByTagName("fecha").item(0).getTextContent();

                /* //<food menu=i>
                Element elementFood = (Element) nodeAnyo;
                NodeList courseList = elementFood.getElementsByTagName("course");
                
                for (int j = 0; j < courseList.getLength(); j++) {
                
                Node nodeCourse = courseList.item(j);
                
                //<course id=j>
                Element elementCourse = (Element) nodeCourse;
                tree += "\tCourse " + elementCourse.getAttribute("id") + ":\n";
                
                //<name>
                String name = elementCourse.getElementsByTagName("name").item(0).getTextContent();
                
                //<price currency="x">
                NodeList nodePrice = elementCourse.getElementsByTagName("price");
                String price = nodePrice.item(0).getTextContent();
                String currency = nodePrice.item(0).getAttributes().getNamedItem("currency").getTextContent();
                
                //<description>
                String description = elementCourse.getElementsByTagName("description").item(0).getTextContent();
                
                //<calories>
                String calories = elementCourse.getElementsByTagName("calories").item(0).getTextContent();
                */
                    tree += "\t\tFecha = " + fecha + "\n";/*
                    tree += "\t\tDescription = " + description + "\n";
                    tree += "\t\tPrice = " + price + " " + currency + "\n";
                    tree += "\t\tCalories = " + calories + "\n";*/
                }
            

        } catch (ParserConfigurationException | SAXException | IOException e) {
            System.err.println("Error: " + e.getMessage());
            tree += "NO CONTENT";
        }

        return tree;
    }

}
