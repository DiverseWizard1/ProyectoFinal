/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.severoochoa.springBootDemo;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Efren
 */
@Service
public class TrabService {

    @Autowired(required = false)
    TrabRepository repository;

    public void trabajadorInformation(String nombreTrab, String apellido) {

        Trabajador usuario = new Trabajador();
        usuario.setNombreTrab(nombreTrab);
        usuario.setApellido(apellido);

        repository.save(usuario);
    }

    public List getAllTrabajadores() {

        List<Trabajador> listaTrabajadores = repository.findAll();

        return listaTrabajadores;
    }

    public Trabajador getTrabajadorById(String id) {

        Optional<Trabajador> usuario = repository.findByNIF(id);

        if (usuario.isPresent()) {
            
            return usuario.get();
        } else {
            
            return null;
        }
    }
    
    public List<Trabajador> getTrabajadoresByName(String nombreTrab){
        
        Optional<List<Trabajador>> listaTrabajadores = repository.findAllTrabajadoresByNombreTrab(nombreTrab);
        
        if(listaTrabajadores.isPresent()){
            
            return listaTrabajadores.get();
        }else{
            
            return null;
        }
    }
    
}
