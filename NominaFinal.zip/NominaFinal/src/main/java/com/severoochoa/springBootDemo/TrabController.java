/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.severoochoa.springBootDemo;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author efren
 */
@RestController

@RequestMapping("/user")

public class TrabController {

    @Autowired
    TrabService service;

    @GetMapping("/list")
    public ResponseEntity<String> listaTrabajadores() {

        List<Trabajador> listaTrabajadores = service.getAllTrabajadores();

        String resultado = "";

        for (Trabajador u : listaTrabajadores) {
            resultado += u.getNombreTrab() + "/n";
        }

        return ResponseEntity.ok(resultado);
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getTrabajadorById(@PathVariable("id") String id) {

        Trabajador usuario = service.getTrabajadorById(id);

        if (usuario == null) {

            return ResponseEntity.noContent().build();
        } else {

            return ResponseEntity.ok(usuario.getNombreTrab());
        }
    }

    @GetMapping("/nombre/{name}")
    public List<Trabajador> getAllTrabajadoresByName(@PathVariable("name") String name) {

        List<Trabajador> listaTrabajadores = service.getTrabajadoresByName(name);

        return listaTrabajadores;
    }

    @PostMapping("/domparser")
    public ResponseEntity<String> readXMLFile(HttpServletRequest request) {
        String response = service.getXMLContent(request);

        return ResponseEntity.ok(response);
    }
}
