/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.severoochoa.springBootDemo.Repositorios;

import com.severoochoa.springBootDemo.Domain.Nomina;
import com.severoochoa.springBootDemo.Domain.Trabajador;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Joel Andreu 1CFS J
 */
@Repository
public interface NominaRepository extends JpaRepository<Nomina, Long>{
    
    <S extends Nomina> S save(S s);
    
    @Override
    List<Nomina> findAll();
    
    Optional<List<Nomina>> findAllNominasByNIFNomina(String NIFNomina);
    
    Optional<List<Nomina>> findAllNominasByCIFNomina(String CIFNomina);
    
}
