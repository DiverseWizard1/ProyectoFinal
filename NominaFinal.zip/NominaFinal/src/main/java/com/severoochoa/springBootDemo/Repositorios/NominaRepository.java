/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.severoochoa.springBootDemo.Repositorios;

import com.severoochoa.springBootDemo.Domain.Nomina;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Joel Andreu 1CFS J
 */
@Repository
public interface NominaRepository extends JpaRepository<Nomina, Long>{
    
    /**
     * Método que almacena objetos nomina en la BD.
     * @param <S> -
     * @param s -
     * @return -
     */
    <S extends Nomina> S save(S s);
    
    /**
     * Método que busca todas los reqistros de objeto nomina.
     * @return Lista de objetos nomina.
     */
    @Override
    List<Nomina> findAll();
    
    /**
     * Método que busca los registros de objeto nomina con un ID concreto.
     * @param NIFNomina ID del trabajador.
     * @return Dato Optional que contiene lista de objetos nomina.
     */
    Optional<List<Nomina>> findAllNominasByNIFNomina(String NIFNomina);
    
    /**
     * Método que busca los registros de objeto nomina con un ID concreto.
     * @param CIFNomina ID de la empresa.
     * @return Dato Opitonal que contiene lista de objetos empresa.
     */
    Optional<List<Nomina>> findAllNominasByCIFNomina(String CIFNomina);
}
