/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.severoochoa.springBootDemo.Servicios;

import com.severoochoa.springBootDemo.Classes.PDFGenerator;
import com.severoochoa.springBootDemo.Domain.Empresa;
import com.severoochoa.springBootDemo.Repositorios.TrabajaRepository;
import com.severoochoa.springBootDemo.Repositorios.TrabRepository;
import com.severoochoa.springBootDemo.Repositorios.NominaRepository;
import com.severoochoa.springBootDemo.Domain.Trabajador;
import com.severoochoa.springBootDemo.Domain.Trabaja;
import com.severoochoa.springBootDemo.Domain.Nomina;
import com.severoochoa.springBootDemo.Repositorios.EmpresaRepository;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 *
 * @author Efren
 */
@Service
public class TrabService {

    @Autowired(required = false)
    TrabRepository repositoryTrabajador;
    
    @Autowired(required = false)
    TrabajaRepository repositoryTrabaja;
    
    @Autowired(required = false)
    NominaRepository repositoryNomina;
    
    @Autowired(required = false)
    EmpresaRepository repositoryEmpresa;
    
    String fileContent = "";

    /**
     * Método que buscar un objeto trabajador según su ID.
     * @param id ID del objeto a buscar.
     * @return Objeto trabajador.
     */
    public Trabajador getTrabajadorById(String id) {

        Optional<Trabajador> usuario = repositoryTrabajador.findByNIF(id);

        if (usuario.isPresent()) {

            return usuario.get();
        } else {

            return null;
        }
    }
    
    /**
     * Método que crea una lista de empresas y la itera para generar nóminas.
     * @param request Archivo XML.
     * @return Dato booleano para confirmar la acción.
     */
    public boolean makeTodasNominas(HttpServletRequest request){
    
        List<Empresa> listaEmpresas = repositoryEmpresa.findAll();
        boolean someSkips = false;
        String anyos [] = getXMLAnyos(request);
        
        for(Empresa e : listaEmpresas){
        
            for(int i = 0; i < anyos.length; i++){
            
                someSkips = makeNominasEmpresa(e.getCIF(), request, anyos[i], "");
            }
        }
        return someSkips;
    }
    
    /**
     * Método que obtiene todos los años que contenga el archivo XML.
     * @param request Archivo XML.
     * @return Array de String con los años del XML.
     */
    public String[] getXMLAnyos (HttpServletRequest request){
    
        String anyos [] = null;

        if(fileContent.isEmpty()){
            fileContent = getFileContent(request);
        }

        // Instantiate the Factory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder db = dbf.newDocumentBuilder();

            //org.w3c.dom.
            Document doc = db.parse(new InputSource(new StringReader(fileContent)));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            // get <anyo>
            NodeList anyoList = doc.getElementsByTagName("anyo");

            //Declaramos el vector con el tamaño segun los años que haya en el documento XML
            anyos = new String [anyoList.getLength()];
            
            for(int i = 0; i < anyos.length; i++){
            
                Node nodeAnyo = anyoList.item(i);
                Element elementAnyo = (Element) nodeAnyo;
                
                anyos[i] = elementAnyo.getElementsByTagName("fecha").item(0).getTextContent();
            }

        } catch (ParserConfigurationException | SAXException | IOException e) {
            System.err.println("Error: " + e.getMessage());
        }

        return anyos;
    
    }
    
    /**
     * Método que itera una lista de trabajadores de una empresa en concreto para generar sus nóminas.
     * @param CIFTrabaja ID de la empresa
     * @param request Archivo XML.
     * @param anyo Anyo buscado.
     * @param mes Mes buscado. Si no se le pasa mes genera las nóminas de todo el año.
     * @return Dato booleano para confirmar la acción.
     */
    public boolean makeNominasEmpresa(String CIFTrabaja, HttpServletRequest request, String anyo, String mes) {

        List<Trabaja> listaTrabaja = getTrabaja(CIFTrabaja);
        List<Trabajador> listaTrabajadores = new ArrayList<>();
        List<Nomina> listaNominasTrabajador;
        List<Nomina> nominasExistentes;
        boolean guardar = true;
        boolean someSkips = false;

        for (Trabaja t : listaTrabaja) {

            listaTrabajadores.add(getTrabajadorById(t.getNIFTrabaja())); //Uremi, curso de docker.

        }

        for (Trabajador t : listaTrabajadores) {

            listaNominasTrabajador = makeNominas(CIFTrabaja, t, request, anyo, mes);
            nominasExistentes = getNominasByTrabajador(t.getNIF());
            
            for(Nomina n : listaNominasTrabajador){
                
                if(nominasExistentes.isEmpty()){
                    nominaInformation(n);
                }else{
                    for(int i = 0 ; i < nominasExistentes.size() && guardar; i++){
                        
                        if(n.getCIFNomina().equals(nominasExistentes.get(i).getCIFNomina()) && n.getNIFNomina().equals(nominasExistentes.get(i).getNIFNomina()) && n.getFechaInicio().equals(nominasExistentes.get(i).getFechaInicio())){
                            guardar = false;
                            someSkips = true;
                        }
                    }
                    if(guardar){
                        nominaInformation(n);
                    }
                }
                guardar = true;
            }
        }

        return someSkips;
    }
    
    /**
     * Método para convertir las variables pasadas de mes y año en fecha tipo String
     * @param mes Mes buscado.
     * @param anyo Año buscado.
     * @return Vector de String con la fecha de inicio del periodo en la posición 0 y la de fin en posición 1.
     */
    public String[] setPeriodo(int mes, String anyo){
        
        String fechas [] = new String [2];
        
        switch(mes){
        
            case 1: fechas[0] = anyo + "-01-01"; fechas[1] = anyo + "-01-31"; break;
            case 2: fechas[0] = anyo + "-02-01"; fechas[1] = anyo + "-02-28"; break;
            case 3: fechas[0] = anyo + "-03-01"; fechas[1] = anyo + "-03-31"; break;
            case 4: fechas[0] = anyo + "-04-01"; fechas[1] = anyo + "-04-30"; break;
            case 5: fechas[0] = anyo + "-05-01"; fechas[1] = anyo + "-05-31"; break;
            case 6: fechas[0] = anyo + "-06-01"; fechas[1] = anyo + "-06-30"; break;
            case 7: fechas[0] = anyo + "-07-01"; fechas[1] = anyo + "-07-31"; break;
            case 8: fechas[0] = anyo + "-08-01"; fechas[1] = anyo + "-08-31"; break;
            case 9: fechas[0] = anyo + "-09-01"; fechas[1] = anyo + "-09-30"; break;
            case 10: fechas[0] = anyo + "-10-01"; fechas[1] = anyo + "-10-31"; break;
            case 11: fechas[0] = anyo + "-11-01"; fechas[1] = anyo + "-11-30"; break;
            case 12: fechas[0] = anyo + "-12-01"; fechas[1] = anyo + "-12-31"; break;
        }
    
        return fechas;
    }

    /**
     * Método generador de nóminas.
     * @param CIF ID del trabajador.
     * @param worker Objeto trabajador.
     * @param request Archivo XML.
     * @param anyo Año de la nómina.
     * @param mes Mes de la nómina.
     * @return Lista de objetos nómina.
     */
    public List<Nomina> makeNominas(String CIF, Trabajador worker, HttpServletRequest request, String anyo, String mes) {

        List<Nomina> nominasTrabajador = new ArrayList<>();
        String fechas [];
        int max;
        
        if(mes.isEmpty()){
            
            max = 12;
        }else{
            
            max = 1;
        }
        
        for (int i = 1; i <= max; i++) {
            
            if(mes.isEmpty()){
            
                fechas = setPeriodo(i, anyo);
            }else{
            
                fechas = setPeriodo(Integer.parseInt(mes), anyo);
            }
            
            List<Trabaja> listaTrabaja = getTrabaja(CIF);
            Trabaja relacionTrabajador = null;

            for (Trabaja tra : listaTrabaja) {

                if (tra.getCIFTrabaja().equals(CIF) && tra.getNIFTrabaja().equals(worker.getNIF())) {
                    relacionTrabajador = tra;
                }
            }

            //Pluses Salariales:  Capacitación profesional (+ 20% del salario base), Gratificaciones extra (prorratas)
            //Pluses NO Salariales: Indemnizaciones o suplidos
            String salarioenString = getSalarioBase(worker.getNIF(), request, anyo);
            double salarioAnual = Double.parseDouble(salarioenString);
            double salarioBase = salarioAnual / 15;
            double capacitacionProfesional = (salarioBase * 20) / 100;

            //Atributos de la nomina
            //Salarial
            double gratificaciones = (salarioBase * 3) / 12; // 3 prorratas
            //No Salariales
            double indemnizaciones = getaleatorio(134.93, 15.13);
            double prestaciones = getaleatorio(47.28, 2.09);

            //Cálculos
            double totDevengado = salarioBase + capacitacionProfesional + gratificaciones + indemnizaciones + prestaciones;
            double eurosHExtra = (salarioAnual / 1790) * 1.50;
            double ganadoHExtra = eurosHExtra * relacionTrabajador.getCantHoras();

            //Bases
            double BCCC = totDevengado - indemnizaciones - prestaciones - ganadoHExtra;
            double BHE = ganadoHExtra;
            double BCCP = BCCC + BHE;

            double CCCTra = BCCC * 0.047;
            double CCCEmp = BCCC * 0.236;
            double ATEP = BCCP * 0.015;
            double desempleoTra;
            double desempleoEmp;
            
            double porcentajesContratos [] = getPorcentajesContrato(request, relacionTrabajador.getTipoContrato());
            desempleoTra = porcentajesContratos[0]/100;
            desempleoEmp = porcentajesContratos[1]/100;
            
            String porcentajeStringTra = String.valueOf(desempleoTra);
            String porcentajeStringEmp = String.valueOf(desempleoEmp);
            
            desempleoTra *= BCCP;
            desempleoEmp *= BCCP;
            double fogasa = BCCP * 0.002;
            double formProTra = BCCP * 0.001;
            double formProEmp = BCCP * 0.006;
            double porHExtraTra = BHE * 0.047;
            double porHExtraEmp = BHE * 0.236;

            double TotAport = CCCTra + desempleoTra + formProTra + porHExtraTra;
            double TotAportEmp = CCCEmp + desempleoEmp + ATEP + formProEmp + fogasa + porHExtraEmp;

            double IRPF = BCCP * 0.12;

            double totDeduc = TotAport + IRPF;

            double liquidoTotal = totDevengado - totDeduc;
            
            Nomina n = new Nomina(totDeduc, TotAportEmp, fechas[0], fechas[1], gratificaciones, TotAport, totDevengado, prestaciones, indemnizaciones, liquidoTotal, worker.getNIF(), CIF, capacitacionProfesional, CCCTra, desempleoTra, porcentajeStringTra, desempleoEmp, porcentajeStringEmp);
            
            nominasTrabajador.add(n);
        }

        return nominasTrabajador;
    }
    
    /**
     * Método que guarda envía los objetos nómina al repositoryNomina para guardarlas en la BD.
     * @param n El objeto nómina.
     */
    public void nominaInformation (Nomina n){
    
        repositoryNomina.save(n);
    }
    
    /**
     * Método que obtiene las nóminas de un trabajador concreto.
     * @param NIFNomina ID del trabajador.
     * @return lista con las nóminas del trabajador.
     */
    public List<Nomina> getNominasByTrabajador(String NIFNomina){
        
        Optional<List<Nomina>> listaNominasOp = repositoryNomina.findAllNominasByNIFNomina(NIFNomina);
        List<Nomina> listaNominas;
        
        if(listaNominasOp.isPresent()){
        
            listaNominas = listaNominasOp.get();
        }else{
        
            return null;
        }
    
        return listaNominas;
    }
    
    /**
     * Método que obtiene las nóminas de una empresa en concreto.
     * @param CIFNomina ID de la empresa.
     * @return Lista de objetos nomina.
     */
    public List<Nomina> getNominasByEmpresa (String CIFNomina){
        
        Optional<List<Nomina>> listaNominasOp = repositoryNomina.findAllNominasByCIFNomina(CIFNomina);
        List<Nomina> listaNominas;
        
        if(listaNominasOp.isPresent()){
            
            listaNominas = listaNominasOp.get();
        }else{
            
            return null;
        }
        
        return listaNominas;
    }
    
    /**
    * Método que devuelve los registros de la tabla trabaja de la BD.
    * @param identificador ID (ID empresa + ID trabajador).
    * @return lista de objetos trabaja.
    */
    public List<Trabaja> getTrabaja(String identificador) {

        Optional<List<Trabaja>> listaTrabajaOp = repositoryTrabaja.findAllTrabajaByciftrabaja(identificador);
        List<Trabaja> listaTrabaja;

        if (listaTrabajaOp.isPresent()) {

            listaTrabaja = listaTrabajaOp.get();
        } else {

            return null;
        }

        return listaTrabaja;
    }

    /**
     * Método que obtiene un número aleatorio entre 2 valores determinados.
     * @param max Valor máximo deseado.
     * @param min Valor mínimo deseado.
     * @return Número aleatorio generado.
     */
    public static double getaleatorio(double max, double min) {
        return Math.random() * max + min;
    }

    /**
     * Método que obtiene el salario base de un trabajador.
     * @param NIF ID del trabajador.
     * @param request Archivo XML.
     * @param anyoBueno Año del salario que se desea.
     * @return salario en formato string.
     */
    public String getSalarioBase(String NIF, HttpServletRequest request, String anyoBueno) {

        Trabajador t1 = getTrabajadorById(NIF);

        int gProf = t1.getGrupoProf();
        int nProf = t1.getNivelProf();
        String aProf = t1.getAreaProf();

        String salarioAnual = getXMLContent(request, gProf, nProf, aProf, anyoBueno);

        return salarioAnual;
    }

    /**
     * Método que obtiene el contenido del XML.
     * @param request Archivo XML.
     * @return Contenido del archivo en formato String.
     */
    public String getFileContent(HttpServletRequest request) {

        try {
            InputStream input = request.getInputStream();

            byte[] data = new byte[1024];

            ByteArrayOutputStream buffer = new ByteArrayOutputStream();

            int nRead;
            while ((nRead = input.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, nRead);
            }

            buffer.flush();
            fileContent = new String(buffer.toByteArray());

        } catch (IOException ex) {
            System.err.println("Error! " + ex.getMessage());
        }

        return fileContent;
    }

    /**
     * Método que controla y maneja el XML para sacar el salario.
     * @param request Archivo XML.
     * @param GPBueno Grupo profesional del trabajador.
     * @param NPBueno Nivel profesional del trabajador.
     * @param APBuena Área profesional del trabajador.
     * @param anyoBueno Año del cual se desea el salario.
     * @return Salario buscado en formato String.
     */
    public String getXMLContent(HttpServletRequest request, int GPBueno, int NPBueno, String APBuena, String anyoBueno) {

        String salarioAnual = "";

        if(fileContent.isEmpty()){
            fileContent = getFileContent(request);
        }

        // Instantiate the Factory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder db = dbf.newDocumentBuilder();

            //org.w3c.dom.
            Document doc = db.parse(new InputSource(new StringReader(fileContent)));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            // get <anyo>
            NodeList anyoList = doc.getElementsByTagName("anyo");

            for (int i = 0; i < anyoList.getLength(); i++) {

                Node nodeAnyo = anyoList.item(i);
                Element elementAnyo = (Element) nodeAnyo;

                String anyo = elementAnyo.getElementsByTagName("fecha").item(0).getTextContent();

                if (anyo.equals(anyoBueno)) {

                    NodeList gruposProfList = elementAnyo.getElementsByTagName("grupo_profesional");

                    for (int j = 0; j < gruposProfList.getLength(); j++) {

                        Node nodeGProf = gruposProfList.item(j);
                        Element elementGProf = (Element) nodeGProf;
                        int atributoNumero = Integer.parseInt(elementGProf.getAttribute("numero"));

                        if (atributoNumero == GPBueno) {

                            Element gruposPadre = (Element) elementGProf.getElementsByTagName("grupos").item(0);
                            NodeList gruposHijo = gruposPadre.getElementsByTagName("grupo");

                            for (int k = 0; k < gruposHijo.getLength(); k++) {

                                Node nodeGrupoHijo = gruposHijo.item(k);
                                Element elementGrupoHijo = (Element) nodeGrupoHijo;
                                int atributoNivel = Integer.parseInt(elementGrupoHijo.getAttribute("nivel"));

                                if (atributoNivel == NPBueno) {

                                    if (APBuena.equals("")) {

                                        salarioAnual = elementGrupoHijo.getElementsByTagName("salarioAnual").item(0).getTextContent();
                                    } else {

                                        String atributoArea = elementGrupoHijo.getAttribute("letra");

                                        if (!atributoArea.equals(APBuena)) {

                                            continue;
                                        } else {

                                            salarioAnual = elementGrupoHijo.getElementsByTagName("salarioAnual").item(0).getTextContent();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

        } catch (ParserConfigurationException | SAXException | IOException e) {
            System.err.println("Error: " + e.getMessage());
        }

        return salarioAnual;
    }
    
    /**
     * Método que genera pdf.
     * @param CIFNomina Id de la empresa.
     * @param NIFNomina Id del trabajador.
     * @param request Archivo XML.
     */
    public void generarPdf(String CIFNomina, String NIFNomina, HttpServletRequest request){
        
        Optional <List<Nomina>> listaNominasOp = Optional.empty();
        List<Nomina> listaNominas = new ArrayList<>();
        
        if(CIFNomina.isEmpty() && NIFNomina.isEmpty()){
            
            listaNominas = repositoryNomina.findAll();
        }else if(NIFNomina.isEmpty()){
            
            listaNominasOp = repositoryNomina.findAllNominasByCIFNomina(CIFNomina);
        }else{
            
            listaNominasOp = repositoryNomina.findAllNominasByNIFNomina(NIFNomina);
        }
        
        String rutaCarpetas;
        
        if(listaNominasOp.isPresent()){
        
            listaNominas = listaNominasOp.get();
        }
        
        if(!listaNominas.isEmpty()){
        
            for(Nomina n : listaNominas){
                
                rutaCarpetas = "";
                
                Empresa e = new Empresa();
                if(repositoryEmpresa.findByCIF(n.getCIFNomina()).isPresent()){
                    e = repositoryEmpresa.findByCIF(n.getCIFNomina()).get();
                }
                
                Trabajador t = new Trabajador();
                if(repositoryTrabajador.findByNIF(n.getNIFNomina()).isPresent()){
                    t = repositoryTrabajador.findByNIF(n.getNIFNomina()).get();
                }
                
                rutaCarpetas += e.getCIF() + "_" + t.getNIF() + "_" + getAnyoMes(n.getFechaInicio()) + ".pdf";
                    
                try{
                    String fecha [] = n.getFechaInicio().split("-");
                    String hExtra = getHExtra(e.getCIF(), t.getNIF());
                    PDFGenerator.crearPDF(n, e, t, rutaCarpetas, getSalarioBase(t.getNIF(), request, fecha[0]), hExtra);
                }catch(Exception ex){
                    
                    System.out.println("Error: " + ex.getMessage());
                }
            }
        }
    }
    
    /**
     * Método que devuelve las horas extra en € de un trabajador con una empresa.
     * @param CIF ID empresa.
     * @param NIF ID trabajador.
     * @return Las horas extra en € en formato String.
     */
    public String getHExtra(String CIF, String NIF){
    
        String hExtra = "";
    
        List<Trabaja> listaTrabaja = repositoryTrabaja.findAll();
        
        for(Trabaja t : listaTrabaja){
        
            if(t.getNIFTrabaja().equals(NIF) && t.getCIFTrabaja().equals(CIF)){
            
                hExtra = String.valueOf(t.getCantHoras());
            }
        }
        
        return hExtra;
    }
    
    /**
     * Metodo que devuelte los porcentajes de desempleo de los diferentes contratos. 
     * @param request Archivo XML.
     * @param tipoContrato Tipo de contrato requerido.
     * @return String con los porcentajes formato Double.
     */
    public double[] getPorcentajesContrato (HttpServletRequest request, int tipoContrato){
        
        if(fileContent.isEmpty()){
            fileContent = getFileContent(request);
        }
        boolean seguir = true;
        double porcentajes[] = new double[2];

        // Instantiate the Factory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder db = dbf.newDocumentBuilder();

            //org.w3c.dom.
            Document doc = db.parse(new InputSource(new StringReader(fileContent)));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            // get <anyo>
            NodeList contratosList = doc.getElementsByTagName("contratos");
            Node nodeContratos = contratosList.item(0);
            Element elementContratos = (Element) nodeContratos;
            
            NodeList listTipos = elementContratos.getElementsByTagName("contrato");
            
            for(int i = 0; i < listTipos.getLength() && seguir ; i++){
            
                Node nodoTipo = listTipos.item(i);
                Element elementoTipo = (Element) nodoTipo;
                int numeroTipo = Integer.parseInt(elementoTipo.getAttribute("numero"));
                
                if(tipoContrato == numeroTipo){
                
                    porcentajes[0] = Double.parseDouble((elementoTipo.getElementsByTagName("trabajador").item(0)).getTextContent());
                    porcentajes[1] = Double.parseDouble((elementoTipo.getElementsByTagName("empresa").item(0)).getTextContent());
                    seguir = false;
                }
            }

        } catch (ParserConfigurationException | SAXException | IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
        
        return porcentajes;
    }
    
    /**
     * Método para obtener solamente el año y el mes de una fecha.
     * @param fecha Fecha deseada.
     * @return Mes y año de la fecha pasada.
     */
    public String getAnyoMes(String fecha){
    
        String vFechas [] = fecha.split("-");
        String fechaEnCadena = vFechas[0] + "-" + vFechas[1];
    
        return fechaEnCadena;
    }
    
    /**
     * Método que comprime los pdf's generados anteriormente.
     * @param sourceDirPath
     * @param zipFilePath
     * @throws IOException 
     */
    public static void pack(String sourceDirPath, String zipFilePath) throws IOException {

        File zip = new File(".\\src\\test\\resources\\pdfNominas.zip");
        if (zip.exists()) {
            zip.delete();
        }
        
        Path p = Files.createFile(Paths.get(zipFilePath));
        Path pp = Paths.get(sourceDirPath);

        try ( ZipOutputStream zs = new ZipOutputStream(Files.newOutputStream(p));  Stream<Path> paths = Files.walk(pp)) {
            paths
                    .filter(path -> !Files.isDirectory(path))
                    .forEach(path -> {
                        ZipEntry zipEntry = new ZipEntry(pp.relativize(path).toString());
                        try {
                            zs.putNextEntry(zipEntry);
                            Files.copy(path, zs);
                            zs.closeEntry();
                        } catch (IOException e) {
                            System.err.println(e);
                        }
                    });
        }
    }
}
