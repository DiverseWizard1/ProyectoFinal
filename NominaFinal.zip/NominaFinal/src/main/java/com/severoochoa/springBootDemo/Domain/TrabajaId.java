/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.severoochoa.springBootDemo.Domain;

import java.io.Serializable;
import java.util.Objects;

/**
 *
 * @author Joel Andreu 1CFS J
 */
public class TrabajaId implements Serializable{
    
    private String niftrabaja;
    private String ciftrabaja;

    public String getNIFTrabaja() {
        return niftrabaja;
    }

    public void setNIFTrabaja(String niftrabaja) {
        this.niftrabaja = niftrabaja;
    }

    public String getCIFTrabaja() {
        return ciftrabaja;
    }

    public void setCIFTrabaja(String ciftrabaja) {
        this.ciftrabaja = ciftrabaja;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 43 * hash + Objects.hashCode(this.niftrabaja);
        hash = 43 * hash + Objects.hashCode(this.ciftrabaja);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final TrabajaId other = (TrabajaId) obj;
        if (!Objects.equals(this.niftrabaja, other.niftrabaja)) {
            return false;
        }
        if (!Objects.equals(this.ciftrabaja, other.ciftrabaja)) {
            return false;
        }
        return true;
    }
    
    
    
}
