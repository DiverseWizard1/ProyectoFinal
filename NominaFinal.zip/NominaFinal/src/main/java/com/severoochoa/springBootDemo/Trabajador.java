/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.severoochoa.springBootDemo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Efren
 */

@Entity
@Table(name = "trabajador")
public class Trabajador {
    
    @Id
    @Column(name = "nif")
    private String NIF;
    @Column(name = "numss")
    private Long numSS;
    @Column(name = "grupoprof")
    private int grupoProf;
    @Column(name = "nivelprof")
    private int nivelProf;
    @Column(name = "areaprof")
    private String areaProf;
    @Column(name = "nombretrab")
    private String nombreTrab;
    @Column(name = "apellidotrab")
    private String apellidoTrab;
    @Column(name = "codpost")
    private int codPost;

    public String getNIF() {
        return NIF;
    }

    public void setNIF(String NIF) {
        this.NIF = NIF;
    }

    public Long getNumSS() {
        return numSS;
    }

    public void setNumSS(Long numSS) {
        this.numSS = numSS;
    }

    public int getGrupoProf() {
        return grupoProf;
    }

    public void setGrupoProf(int grupoProf) {
        this.grupoProf = grupoProf;
    }

    public int getNivelProf() {
        return nivelProf;
    }

    public void setNivelProf(int nivelProf) {
        this.nivelProf = nivelProf;
    }

    public String getAreaProf() {
        return areaProf;
    }

    public void setAreaProf(String areaProf) {
        this.areaProf = areaProf;
    }

    public String getNombreTrab() {
        return nombreTrab;
    }

    public void setNombreTrab(String nombreTrab) {
        this.nombreTrab = nombreTrab;
    }

    public String getApellido() {
        return apellidoTrab;
    }

    public void setApellido(String apellidoTrab) {
        this.apellidoTrab = apellidoTrab;
    }

    public int getCodPost() {
        return codPost;
    }

    public void setCodPost(int codPost) {
        this.codPost = codPost;
    }

}
