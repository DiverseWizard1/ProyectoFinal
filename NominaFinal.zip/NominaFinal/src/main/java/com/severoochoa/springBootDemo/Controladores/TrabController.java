/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.severoochoa.springBootDemo.Controladores;

import com.itextpdf.text.DocumentException;
import com.severoochoa.springBootDemo.Domain.Nomina;
import com.severoochoa.springBootDemo.Domain.Trabajador;
import com.severoochoa.springBootDemo.Classes.PDFGenerator;
import com.severoochoa.springBootDemo.Servicios.TrabService;
import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author efren
 */
@RestController
@RequestMapping("/user")
public class TrabController {

    @Autowired
    TrabService service;

    @GetMapping("/list")
    public ResponseEntity<String> listaTrabajadores() {

        List<Trabajador> listaTrabajadores = service.getAllTrabajadores();

        String resultado = "";

        for (Trabajador u : listaTrabajadores) {
            resultado += u.getNombreTrab() + "/n";
        }

        return ResponseEntity.ok(resultado);
    }

    @GetMapping("/{id}")
    public ResponseEntity<String> getTrabajadorById(@PathVariable("id") String id) {

        Trabajador usuario = service.getTrabajadorById(id);

        if (usuario == null) {

            return ResponseEntity.noContent().build();
        } else {

            return ResponseEntity.ok(usuario.getNombreTrab());
        }
    }
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /*
    Generar PDF:
        - Las de una empresa.
        - Las de un trabajador.
        - Las de un trabajador en un mes concreto.
    Buscar Nómina:
        - Las de una empresa.                                   V
        - LAs de un trabajador.                                 V
    Generar Nómina:
        -Todas de una empresa en un año.                        V
        -De una empresa en un año en un periodo/mes.            V
        -Todas las nóminas. (Todas empresas, todo de todo).     V
    */
    
    /**
     * Método que devuelve todas las nóminas de un trabajador.
     * @param idtrabajador Nif del trabajador.
     * @return Lista de objetos Nómina.
     */
    @GetMapping("/buscarnomina/trabajador/{idtrabajador}")
    public List<Nomina> bucarNominasByTrabajador (@PathVariable("idtrabajador") String idtrabajador){
        
        List<Nomina> listaNominasTrabajador = service.getNominasByTrabajador(idtrabajador);
        
        return listaNominasTrabajador;
    }
    
    /**
     * Método que devuelve todas las nóminas de una empresa.
     * @param idempresa Cif de la empresa.
     * @return Lista de objetos Nómina.
     */
    @GetMapping("/buscarnomina/empresa/{idempresa}")
    public List<Nomina> buscarNominasByEmpresa (@PathVariable("idempresa") String idempresa) {
        
        List<Nomina> listaNominasEmpresa = service.getNominasByEmpresa(idempresa);
        
        return listaNominasEmpresa;
    }
    
    
    /**
     * Método que devuelve las nóminas de una empresa de un año específico.
     * @param empresa Cif de la empresa.
     * @param anyo Año de las nóminas deseado.
     * @param request Fichero XML.
     * @return Cadena de texto sobre el resultado de la operación.
     */
    @PostMapping("/generarnomina/{empresa}/{anyo}") //Genera todas las nóminas de X Empresa en X año.
    public String makeNominasEmpresa(@PathVariable("empresa") String empresa, @PathVariable("anyo") String anyo, HttpServletRequest request){
        
        String mes = "";
        boolean someSkips = service.makeNominasEmpresa(empresa, request, anyo, mes);
        
        if(!someSkips){
            return "Nominas de cada trabajador de una empresa hechas.";
        }else{
            return "Algunas de las nominas generadas ya existían, por lo tanto, no se han guardado.";
        }
    }
    
    @PostMapping("/generarnomina/{empresa}/{anyo}/{mes}")
    public String makeNominasEmpresaMes(@PathVariable("empresa") String CIFTrabaja, HttpServletRequest request, @PathVariable("anyo") String fecha, @PathVariable("mes") String mes){
    
        boolean someSkips = service.makeNominasEmpresa(CIFTrabaja, request, fecha, mes);
        
        if(!someSkips){
            return "Nominas de un mes de cada trabajador de una empresa hechas.";
        }else{
            return "Algunas de las nominas generadas ya existían, por lo tanto, no se han guardado.";
        }
    }
    
    @PostMapping("/generarnomina/todas")
    public String makeNominasTodas (HttpServletRequest request){
    
        boolean someSkips = service.makeTodasNominas(request);
        
        if(!someSkips){
            return "Todas las nóminas generadas.";
        }else{
            return "Algunas de las nominas generadas ya existían, por lo tanto, no se han guardado.";
        }
    }
    
    @PostMapping("/pdf")
    public void pfd() throws IOException, DocumentException {

        PDFGenerator.crearPDF();
    }
}
