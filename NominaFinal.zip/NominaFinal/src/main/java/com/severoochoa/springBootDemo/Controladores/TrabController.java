/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.severoochoa.springBootDemo.Controladores;

import com.itextpdf.text.DocumentException;
import com.severoochoa.springBootDemo.Domain.Nomina;
import com.severoochoa.springBootDemo.Servicios.TrabService;
import java.io.IOException;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author efren
 */
@RestController
@RequestMapping("/user")
public class TrabController {

    @Autowired
    TrabService service;

    ////////////////////////////////////////////////////////////////////////////////////////////////////////
    /*
    Generar PDF:
        - Las de una empresa.                                   HECHO
        - Las de un trabajador.                                 HECHO
        - Todas.                                                HECHO
    Buscar Nómina:
        - Las de una empresa.                                   HECHO
        - Las de un trabajador.                                 HECHO
    Generar Nómina:
        -Todas de una empresa en un año.                        HECHO
        -De una empresa en un año en un periodo/mes.            HECHO
        -Todas las nóminas. (Todas empresas, todo de todo).     HECHO
     */
    /**
     * Microservicio que devuelve todas las nóminas de un trabajador.
     *
     * @param idtrabajador Nif del trabajador.
     * @return Lista de objetos Nómina.
     */
    @GetMapping("/buscarnomina/trabajador/{idtrabajador}")
    public List<Nomina> bucarNominasByTrabajador(@PathVariable("idtrabajador") String idtrabajador) {

        List<Nomina> listaNominasTrabajador = service.getNominasByTrabajador(idtrabajador);

        return listaNominasTrabajador;
    }

    /**
     * Microservicio que devuelve todas las nóminas de una empresa.
     *
     * @param idempresa Cif de la empresa.
     * @return Lista de objetos Nómina.
     */
    @GetMapping("/buscarnomina/empresa/{idempresa}")
    public List<Nomina> buscarNominasByEmpresa(@PathVariable("idempresa") String idempresa) {

        List<Nomina> listaNominasEmpresa = service.getNominasByEmpresa(idempresa);

        return listaNominasEmpresa;
    }

    /**
     * Microservicio que devuelve las nóminas de una empresa de un año
     * específico.
     *
     * @param empresa Cif de la empresa.
     * @param anyo Año de las nóminas deseado.
     * @param request Fichero XML.
     * @return Cadena de texto sobre el resultado de la operación.
     */
    @PostMapping("/generarnomina/{empresa}/{anyo}") //Genera todas las nóminas de X Empresa en X año.
    public String makeNominasEmpresa(@PathVariable("empresa") String empresa, @PathVariable("anyo") String anyo, HttpServletRequest request) {

        String mes = "";
        boolean someSkips = service.makeNominasEmpresa(empresa, request, anyo, mes);

        if (!someSkips) {
            return "Nominas de cada trabajador de una empresa hechas.";
        } else {
            return "Algunas de las nominas generadas ya existían, por lo tanto, no se han guardado.";
        }
    }

    /**
     * Microservicio que genera nóminas según empresa, año y mes concretos y los
     * almacena en la BD.
     *
     * @param CIFTrabaja ID de la empresa.
     * @param request Archivo XML
     * @param fecha Fecha (año) buscada.
     * @param mes Mes buscado.
     * @return Cadena de texto sobre el resultado de la operación.
     */
    @PostMapping("/generarnomina/{empresa}/{anyo}/{mes}")
    public String makeNominasEmpresaMes(@PathVariable("empresa") String CIFTrabaja, HttpServletRequest request, @PathVariable("anyo") String fecha, @PathVariable("mes") String mes) {

        boolean someSkips = service.makeNominasEmpresa(CIFTrabaja, request, fecha, mes);

        if (!someSkips) {
            return "Nominas de un mes de cada trabajador de una empresa hechas.";
        } else {
            return "Algunas de las nominas generadas ya existían, por lo tanto, no se han guardado.";
        }
    }

    /**
     * Microservicio que genera todas las nóminas posibles de la BD y las
     * almacena.
     *
     * @param request Archivo XML.
     * @return Cadena de texto sobre el resultado de la operación.
     */
    @PostMapping("/generarnomina/todas")
    public String makeNominasTodas(HttpServletRequest request) {

        boolean someSkips = service.makeTodasNominas(request);

        if (!someSkips) {
            return "Todas las nóminas generadas.";
        } else {
            return "Algunas de las nominas generadas ya existían, por lo tanto, no se han guardado.";
        }
    }

    /**
     * Microservicio que crea archivos PDF de una empresa en concreto.
     *
     * @param CIFNomina ID de la empresa.
     * @param request Archivo XML.
     * @throws IOException
     * @throws DocumentException
     */
    @PostMapping("/pdf/empresa/{empresa}")
    public void pdfPorEmpresa(@PathVariable("empresa") String CIFNomina, HttpServletRequest request) throws IOException, DocumentException {

        String NIFNomina = "";
        service.generarPdf(CIFNomina, NIFNomina, request);
    }

    /**
     * Microservicio que crea archivos PDF de un trabajador en concreto.
     *
     * @param NIFNomina ID del trabajador.
     * @param request Archivo XML.
     * @throws IOException
     * @throws DocumentException
     */
    @PostMapping("/pdf/trabajador/{trabajador}")
    public void pdfPorTrabajador(@PathVariable("trabajador") String NIFNomina, HttpServletRequest request) throws IOException, DocumentException {

        String CIFNomina = "";
        service.generarPdf(CIFNomina, NIFNomina, request);
    }

    /**
     * Microservicio que genera todos los PDF de todas las nóminas de la BD.
     *
     * @param request Archivo XML.
     * @throws IOException
     * @throws DocumentException
     */
    @PostMapping("/pdf/todas")
    public void pdfTodas(HttpServletRequest request) throws IOException, DocumentException {

        String NIFNomina, CIFNomina;
        NIFNomina = "";
        CIFNomina = "";
        service.generarPdf(CIFNomina, NIFNomina, request);
    }

    /**
     * Microservicio que comprime todos los pdf generados anteriormente.
     */
    @PostMapping("/zip")
    public void zip() {

        try {

            TrabService.pack(".\\target\\classes\\PDFsRetos", ".\\target\\classes\\pdfNominas.zip");
        } catch (Exception ex) {

            System.out.println("Error: " + ex.getMessage());
        }
    }
}
