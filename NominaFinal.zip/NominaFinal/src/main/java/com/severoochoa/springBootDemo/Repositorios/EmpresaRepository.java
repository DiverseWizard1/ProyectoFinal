/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.severoochoa.springBootDemo.Repositorios;

import com.severoochoa.springBootDemo.Domain.Empresa;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Joel Andreu 1CFS J
 */
@Repository
public interface EmpresaRepository extends JpaRepository<Empresa, Long>{
    
    /**
     * Método que busca todas los reqistros de objeto empresa.
     * @return Lista de objetos empresa.
     */
    @Override
    List<Empresa> findAll();
    
    /**
     * Método que busca los registros de objeto empresa con un ID concreto.
     * @param CIF ID del objeto empresa.
     * @return Dato Optional que contiene lista de objetos empresa.
     */
    Optional<Empresa> findByCIF(String CIF);
}
