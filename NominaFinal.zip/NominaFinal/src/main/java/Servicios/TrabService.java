/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicios;

import Repositorios.TrabajaRepository;
import Repositorios.TrabRepository;
import Repositorios.NominaRepository;
import Domain.Trabajador;
import Domain.Trabaja;
import Domain.Nomina;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.servlet.http.HttpServletRequest;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 *
 * @author Efren
 */
@Service
public class TrabService {

    @Autowired(required = false)
    TrabRepository repositoryTrabajador;
    
    @Autowired(required = false)
    TrabajaRepository repositoryTrabaja;
    
    @Autowired(required = false)
    NominaRepository repositoryNomina;

    public void trabajadorInformation(String nombreTrab, String apellido) {

        Trabajador usuario = new Trabajador();
        usuario.setNombreTrab(nombreTrab);
        usuario.setApellido(apellido);

        repositoryTrabajador.save(usuario);
    }

    public List getAllTrabajadores() {

        List<Trabajador> listaTrabajadores = repositoryTrabajador.findAll();

        return listaTrabajadores;
    }

    public Trabajador getTrabajadorById(String id) {

        Optional<Trabajador> usuario = repositoryTrabajador.findByNIF(id);

        if (usuario.isPresent()) {

            return usuario.get();
        } else {

            return null;
        }
    }

    public List<Trabajador> getTrabajadoresByName(String nombreTrab) {

        Optional<List<Trabajador>> listaTrabajadores = repositoryTrabajador.findAllTrabajadoresByNombreTrab(nombreTrab);

        if (listaTrabajadores.isPresent()) {

            return listaTrabajadores.get();
        } else {

            return null;
        }
    }

    ////////////////////////////////////////////////////////////////////////////////
    public String makeNominasEmpresa(String CIFTrabaja, HttpServletRequest request, String anyo) {

        List<Trabaja> listaTrabaja = getTrabaja(CIFTrabaja);
        List<Trabajador> listaTrabajadores = new ArrayList<>();
        List<Nomina> listaNominasTrabajador = new ArrayList<>();

        for (Trabaja t : listaTrabaja) {

            listaTrabajadores.add(getTrabajadorById(t.getNIFTrabaja())); //Uremi, curso de docker.

        }

        for (Trabajador t : listaTrabajadores) {

            listaNominasTrabajador = makeNominas(CIFTrabaja, t, request, anyo);
            
            for(Nomina n : listaNominasTrabajador){
            
                nominaInformation(n);
            }

        }

        return "Service";
    }
    
    /*public String makeNominaEmpresaMes(String CIFTrabaja, HttpServletRequest request, String anyo, String mes){
    
        
    
    }*/

    public List<Nomina> makeNominas(String CIF, Trabajador worker, HttpServletRequest request, String anyo) {

        List<Nomina> nominasTrabajador = new ArrayList<>();
        
        for (int i = 1; i <= 12; i++) {

            String FechaInicio = "";
            String FechaFin = "";

            switch(i){
        
                case 1: FechaInicio = anyo + "/01/01"; FechaFin = anyo + "01/31"; break;
                case 2: FechaInicio = anyo + "/02/01"; FechaFin = anyo + "02/28"; break;
                case 3: FechaInicio = anyo + "/03/01"; FechaFin = anyo + "03/31"; break;
                case 4: FechaInicio = anyo + "/04/01"; FechaFin = anyo + "04/30"; break;
                case 5: FechaInicio = anyo + "/05/01"; FechaFin = anyo + "05/31"; break;
                case 6: FechaInicio = anyo + "/06/01"; FechaFin = anyo + "06/30"; break;
                case 7: FechaInicio = anyo + "/07/01"; FechaFin = anyo + "07/31"; break;
                case 8: FechaInicio = anyo + "/08/01"; FechaFin = anyo + "08/31"; break;
                case 9: FechaInicio = anyo + "/09/01"; FechaFin = anyo + "09/30"; break;
                case 10: FechaInicio = anyo + "/10/01"; FechaFin = anyo + "10/31"; break;
                case 11: FechaInicio = anyo + "/11/01"; FechaFin = anyo + "11/30"; break;
                case 12: FechaInicio = anyo + "/12/01"; FechaFin = anyo + "12/31"; break;
            }
            
            List<Trabaja> listaTrabaja = getTrabaja(CIF);
            Trabaja relacionTrabajador = null;

            for (Trabaja tra : listaTrabaja) {

                if (tra.getCIFTrabaja() == CIF && tra.getNIFTrabaja() == worker.getNIF()) {
                    relacionTrabajador = tra;
                }
            }

            //Pluses Salariales:  Capacitación profesional (+ 20% del salario base), Gratificaciones extra (prorratas)
            //Pluses NO Salariales: Indemnizaciones o suplidos
            double salarioAnual = Double.parseDouble(getSalarioBase(worker.getNIF(), request, anyo));
            double salarioBase = salarioAnual / 15;
            double capacitacionProfesional = salarioBase + (salarioBase * 20) / 100;

            //Atributos de la nomina
            //Salarial
            double gratificaciones = (salarioBase * 3) / 12; // 3 prorratas
            //No Salariales
            double indemnizaciones = getaleatorio(134.93, 15.13);
            double prestaciones = getaleatorio(47.28, 2.09);

            //Cálculos
            double totDevengado = salarioBase + capacitacionProfesional + gratificaciones + indemnizaciones + prestaciones;
            double eurosHExtra = (salarioAnual / 1790) * 1.50;
            double ganadoHExtra = eurosHExtra * relacionTrabajador.getCantHoras();

            //Bases
            double BCCC = totDevengado - indemnizaciones - prestaciones - ganadoHExtra;
            double BHE = ganadoHExtra;
            double BCCP = BCCC + BHE;

            double CCCTra = BCCC * 0.047;
            double CCCEmp = BCCC * 0.236;
            double ATEP = BCCP * 0.015;
            double desempleoTra = 0;
            double desempleoEmp = 0;
            if (relacionTrabajador.getTipoContrato() != 4) {

                desempleoTra = 0.0155;
                desempleoEmp = 0.055;
            } else {

                desempleoTra = 0.0160;
                desempleoEmp = 0.0670;
            }
            desempleoTra *= BCCP;
            desempleoEmp *= BCCP;
            double fogasa = BCCP * 0.002;
            double formProTra = BCCP * 0.001;
            double formProEmp = BCCP * 0.006;
            double porHExtraTra = BHE * 0.047;
            double porHExtraEmp = BHE * 0.236;

            double TotAport = CCCTra + desempleoTra + formProTra + porHExtraTra;
            double TotAportEmp = CCCEmp + desempleoEmp + ATEP + formProEmp + fogasa;

            double IRPF = totDevengado * 0.12;

            double totDeduc = TotAport + IRPF;

            double liquidoTotal = totDevengado - totDeduc;
            
            Nomina n = new Nomina(totDeduc, TotAportEmp, FechaInicio, FechaFin, gratificaciones, TotAport, totDevengado, prestaciones, indemnizaciones, liquidoTotal, worker.getNIF(), CIF, capacitacionProfesional);
            
            nominasTrabajador.add(n);
        }

        return nominasTrabajador;
    }
    
    public void nominaInformation (Nomina n){
    
        repositoryNomina.save(n);
    }

    public List<Trabaja> getTrabaja(String identificador) {

        Optional<List<Trabaja>> listaTrabajaOp = repositoryTrabaja.findAllTrabajaByciftrabaja(identificador);

        List<Trabaja> listaTrabaja;

        if (listaTrabajaOp.isPresent()) {

            listaTrabaja = listaTrabajaOp.get();

        } else {

            return null;
        }

        return listaTrabaja;
    }

    public static double getaleatorio(double max, double min) {
        return Math.random() * max + min;
    }

    public String getSalarioBase(String NIF, HttpServletRequest request, String anyoBueno) {

        Trabajador t1 = getTrabajadorById(NIF);

        int gProf = t1.getGrupoProf();
        int nProf = t1.getNivelProf();
        String aProf = t1.getAreaProf();

        String salarioAnual = getXMLContent(request, gProf, nProf, aProf, anyoBueno);

        return salarioAnual;
    }

    public String getFileContent(HttpServletRequest request) {

        String fileContent = "";

        try {
            InputStream input = request.getInputStream();

            byte[] data = new byte[1024];

            ByteArrayOutputStream buffer = new ByteArrayOutputStream();

            int nRead;
            while ((nRead = input.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, nRead);
            }

            buffer.flush();
            fileContent = new String(buffer.toByteArray());

        } catch (IOException ex) {
            System.err.println("Error! " + ex.getMessage());
        }

        return fileContent;
    }

    public String getXMLContent(HttpServletRequest request, int GPBueno, int NPBueno, String APBuena, String anyoBueno) {

        String salarioAnual = "";

        String fileContent = getFileContent(request);

        // Instantiate the Factory
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        try {
            DocumentBuilder db = dbf.newDocumentBuilder();

            //org.w3c.dom.
            Document doc = db.parse(new InputSource(new StringReader(fileContent)));

            // optional, but recommended
            // http://stackoverflow.com/questions/13786607/normalization-in-dom-parsing-with-java-how-does-it-work
            doc.getDocumentElement().normalize();

            // get <anyo>
            NodeList anyoList = doc.getElementsByTagName("anyo");

            for (int i = 0; i < anyoList.getLength(); i++) {

                Node nodeAnyo = anyoList.item(i);
                Element elementAnyo = (Element) nodeAnyo;

                String anyo = elementAnyo.getElementsByTagName("fecha").item(0).getTextContent();

                if (anyo.equals(anyoBueno)) {

                    //get fecha
                    NodeList gruposProfList = elementAnyo.getElementsByTagName("grupo_profesional");

                    for (int j = 0; j < gruposProfList.getLength(); j++) {

                        Node nodeGProf = gruposProfList.item(j);
                        Element elementGProf = (Element) nodeGProf;
                        int atributoNumero = Integer.parseInt(elementGProf.getAttribute("numero"));

                        if (atributoNumero == GPBueno) {

                            Element gruposPadre = (Element) elementGProf.getElementsByTagName("grupos").item(0);
                            NodeList gruposHijo = gruposPadre.getElementsByTagName("grupo");

                            for (int k = 0; k < gruposHijo.getLength(); k++) {

                                Node nodeGrupoHijo = gruposHijo.item(k);
                                Element elementGrupoHijo = (Element) nodeGrupoHijo;
                                int atributoNivel = Integer.parseInt(elementGrupoHijo.getAttribute("nivel"));

                                if (atributoNivel == NPBueno) {

                                    if (APBuena.equals("")) {

                                        salarioAnual = elementGrupoHijo.getElementsByTagName("salarioAnual").item(0).getTextContent();

                                        //return salarioAnual;
                                    } else {

                                        String atributoArea = elementGrupoHijo.getAttribute("letra");

                                        if (!atributoArea.equals(APBuena)) {

                                            continue;

                                        } else {

                                            salarioAnual = elementGrupoHijo.getElementsByTagName("salarioAnual").item(0).getTextContent();

                                            //return salarioAnual;
                                        }

                                    }

                                }

                            }

                        }

                    }
                }

            }

        } catch (ParserConfigurationException | SAXException | IOException e) {
            System.err.println("Error: " + e.getMessage());
        }

        return salarioAnual;
    }

}
