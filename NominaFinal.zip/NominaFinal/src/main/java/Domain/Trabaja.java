/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Domain;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 *
 * @author Joel Andreu 1CFS J
 */

@Entity
@Table(name = "trabaja")
@IdClass(TrabajaId.class)
public class Trabaja{
    
    @Id
    //@Column (name = "niftrabaja")
    private String niftrabaja;
    @Id
    //@Column (name = "ciftrabaja")
    private String ciftrabaja;
    @Column (name = "canthoras")
    private int CantHoras;
    @Column (name = "fechahoras")
    private String FechaHoras;
    @Column (name = "tipocontrato")
    private int TipoContrato;

    public String getNIFTrabaja() {
        return niftrabaja;
    }

    public void setNIFTrabaja(String niftrabaja) {
        this.niftrabaja = niftrabaja;
    }

    public String getCIFTrabaja() {
        return ciftrabaja;
    }

    public void setciftrabaja(String ciftrabaja) {
        this.ciftrabaja = ciftrabaja;
    }

    public int getCantHoras() {
        return CantHoras;
    }

    public void setCantHoras(int CantHoras) {
        this.CantHoras = CantHoras;
    }

    public String getFechaHoras() {
        return FechaHoras;
    }

    public void setFechaHoras(String FechaHoras) {
        this.FechaHoras = FechaHoras;
    }

    public int getTipoContrato() {
        return TipoContrato;
    }

    public void setTipoContrato(int TipoContrato) {
        this.TipoContrato = TipoContrato;
    }
    
    
    
}
