/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Repositorios;

import Domain.Nomina;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Joel Andreu 1CFS J
 */
@Repository
public interface NominaRepository extends JpaRepository<Nomina, Long>{
    
    <S extends Nomina> S save(S s);
    
}
