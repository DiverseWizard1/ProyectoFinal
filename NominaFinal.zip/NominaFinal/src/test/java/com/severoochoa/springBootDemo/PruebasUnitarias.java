/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.severoochoa.springBootDemo;

import com.severoochoa.springBootDemo.Servicios.TrabService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Joel Andreu 1CFSj
 */
public class PruebasUnitarias {

    public PruebasUnitarias() {
    }

    @BeforeAll
    public static void setUpClass() {
    }

    @AfterAll
    public static void tearDownClass() {
    }

    @BeforeEach
    public void setUp() {
    }

    @AfterEach
    public void tearDown() {
    }

    @Test
    public void periodoTiempo() {
        TrabService nomina = new TrabService();
        String periodo[] = nomina.setPeriodo(6, "2023");
        assertEquals(periodo[0], "2023-06-01");
        assertEquals(periodo[1], "2023-06-30");
    }
    
//    @Test
//    public void gethExtra(){
//        TrabService nomina = new TrabService();
//        String horas = nomina.getHExtra("V38887654","W12477458");
//        assertEquals("10",horas);
//    }
    
    @Test void getAnyoYMes(){
        TrabService nomina = new TrabService();
        String fecha = "2030-01-15";
        String fechaNueva = nomina.getAnyoMes(fecha);
        assertEquals("2030-01", fechaNueva);
    }
}
